import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ReactiveFormConfig, ErrorMessageBindingStrategy } from '@rxweb/reactive-form-validators';

@Component({
  // tslint:disable-next-line
  selector: 'body',
  template: `
  <!-- https://github.com/aitboudad/ngx-loading-bar -->
  <ngx-loading-bar></ngx-loading-bar>
  <!-- https://www.npmjs.com/package/ngx-spinner -->
  <ngx-spinner
    bdColor="rgba(225,225,225,0)"
    size="medium"
    color="#1B8EB7"
    type="ball-clip-rotate"
  >
  </ngx-spinner>

  <router-outlet></router-outlet>
  `
})
export class AppComponent implements OnInit {
  constructor(private router: Router) { 

    ReactiveFormConfig.set({
      reactiveForm: {
         errorMessageBindingStrategy: ErrorMessageBindingStrategy.OnDirtyOrTouched
      },
      validationMessage: {
        required: "This field is required.",
        digit: "This field should be a digit.",
        minNumber: "Minimum value shoud be {{1}}.",
        maxLength: "Max length {{1}}.",
        email: "This field should be an email.", 
        unique: "This field should be unique."     
      }
    });
  }

  ngOnInit() {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }
}
