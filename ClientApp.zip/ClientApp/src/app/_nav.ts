interface NavAttributes {
  [propName: string]: any;
}
interface NavWrapper {
  attributes: NavAttributes;
  element: string;
}
interface NavBadge {
  text: string;
  variant: string;
}
interface NavLabel {
  class?: string;
  variant: string;
}

export interface NavData {
  name?: string;
  url?: string;
  icon?: string;
  badge?: NavBadge;
  title?: boolean;
  children?: NavData[];
  variant?: string;
  attributes?: NavAttributes;
  divider?: boolean;
  class?: string;
  label?: NavLabel;
  wrapper?: NavWrapper;
}

export const navItems: NavData[] = [
  {
    name: 'Dashboard',
    url: '/app-dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'Home'
    }
  },
  {
    title: true,
    name: 'User'
  },
  {
    name: 'Report User',
    url: '/report-user',
    icon: 'icon-puzzle',
    children: [    
      {
        name: 'Channel',
        url: '/report-user/channels',
        icon: 'icon-puzzle'
      },
      {
        name: 'Channel Partner',
        url: '/report-user/channel-partners',
        icon: 'icon-puzzle'
      },
      {
        name: 'Role',
        url: '/report-user/roles',
        icon: 'icon-puzzle'
      },
      {
        name: 'User',
        url: '/report-user/users',
        icon: 'icon-puzzle'
      },
      {
        name: 'Delegate',
        url: '/report-user/delegates',
        icon: 'icon-puzzle'
      },
      {
        name: 'Hierarchy',
        url: '/report-user/hierarchies',
        icon: 'icon-puzzle'
      },
      {
        name: 'User Vs Role',
        url: '/report-user/user-role-mapps',
        icon: 'icon-puzzle'
      }     
    ]
  },
  {
    name: 'Administrator User',
    url: '/base',
    icon: 'icon-puzzle',
    children: [
      {
        name: 'User',
        url: '/admin-panel/users',
        icon: 'icon-puzzle'
      },
      {
        name: 'Role',
        url: '/admin-panel/roles',
        icon: 'icon-puzzle'
      },
      {
        name: 'User Vs Role',
        url: '/admin-panel/user-vs-role',
        icon: 'icon-puzzle'
      },
      {
        name: 'Page',
        url: '/admin-panel/pages',
        icon: 'icon-puzzle'
      },
      {
        name: 'Role Vs Page',
        url: '/admin-panel/role-vs-page',
        icon: 'icon-puzzle'
      }     
    ]
  },

  {
    title: true,
    name: 'Survey'
  },
  {
    name: 'Static Survey',
    url: '/static-survey',
    icon: 'icon-puzzle',
    children: [
      {
        name: 'Channel',
        url: '/static-survey/question-channels',
        icon: 'icon-puzzle'
      },
      {
        name: 'Question Set',
        url: '/static-survey/question-sets',
        icon: 'icon-puzzle'
      },   
    ]
  },
  {
    name: 'Survey Config',
    url: '/survey-config',
    icon: 'icon-puzzle',
    children: [
      {
        name: 'Non IVR',
        url: '/survey-config/non-ivr',
        icon: 'icon-puzzle'
      },
      {
        name: 'IVR',
        url: '/survey-config/ivr',
        icon: 'icon-puzzle'
      }    
    ]
  },
  {
    name: 'Dynamic Survey',
    url: '/dynamic-survey',
    icon: 'icon-puzzle',
    children: [
      {
        name: 'Dynamic Survey List',
        url: '/dynamic-survey/dynamicsurveylist',
        icon: 'icon-puzzle'
      },
      // {
      //   name: 'IVR',
      //   url: '/survey-config/ivr',
      //   icon: 'icon-puzzle'
      // }    
    ]
  }
];


export const tmplNavItems: NavData[] = [
  {
    title: true,
    name: 'Tmpls'
  },
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  {
    title: true,
    name: 'Theme'
  },
  {
    name: 'Colors',
    url: '/theme/colors',
    icon: 'icon-drop'
  },
  {
    name: 'Typography',
    url: '/theme/typography',
    icon: 'icon-pencil'
  },
  {
    title: true,
    name: 'Components'
  },
  {
    name: 'Base',
    url: '/base',
    icon: 'icon-puzzle',
    children: [
      {
        name: 'Cards',
        url: '/base/cards',
        icon: 'icon-puzzle'
      },
      {
        name: 'Carousels',
        url: '/base/carousels',
        icon: 'icon-puzzle'
      },
      {
        name: 'Collapses',
        url: '/base/collapses',
        icon: 'icon-puzzle'
      },
      {
        name: 'Forms',
        url: '/base/forms',
        icon: 'icon-puzzle'
      },
      {
        name: 'Pagination',
        url: '/base/paginations',
        icon: 'icon-puzzle'
      },
      {
        name: 'Popovers',
        url: '/base/popovers',
        icon: 'icon-puzzle'
      },
      {
        name: 'Progress',
        url: '/base/progress',
        icon: 'icon-puzzle'
      },
      {
        name: 'Switches',
        url: '/base/switches',
        icon: 'icon-puzzle'
      },
      {
        name: 'Tables',
        url: '/base/tables',
        icon: 'icon-puzzle'
      },
      {
        name: 'Tabs',
        url: '/base/tabs',
        icon: 'icon-puzzle'
      },
      {
        name: 'Tooltips',
        url: '/base/tooltips',
        icon: 'icon-puzzle'
      }
    ]
  },
  {
    name: 'Buttons',
    url: '/buttons',
    icon: 'icon-cursor',
    children: [
      {
        name: 'Buttons',
        url: '/buttons/buttons',
        icon: 'icon-cursor'
      },
      {
        name: 'Dropdowns',
        url: '/buttons/dropdowns',
        icon: 'icon-cursor'
      },
      {
        name: 'Brand Buttons',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      }
    ]
  },
  {
    name: 'Charts',
    url: '/charts',
    icon: 'icon-pie-chart'
  },
  {
    name: 'Icons',
    url: '/icons',
    icon: 'icon-star',
    children: [
      {
        name: 'CoreUI Icons',
        url: '/icons/coreui-icons',
        icon: 'icon-star',
        badge: {
          variant: 'success',
          text: 'NEW'
        }
      },
      {
        name: 'Flags',
        url: '/icons/flags',
        icon: 'icon-star'
      },
      {
        name: 'Font Awesome',
        url: '/icons/font-awesome',
        icon: 'icon-star',
        badge: {
          variant: 'secondary',
          text: '4.7'
        }
      },
      {
        name: 'Simple Line Icons',
        url: '/icons/simple-line-icons',
        icon: 'icon-star'
      }
    ]
  },
  {
    name: 'Notifications',
    url: '/notifications',
    icon: 'icon-bell',
    children: [
      {
        name: 'Alerts',
        url: '/notifications/alerts',
        icon: 'icon-bell'
      },
      {
        name: 'Badges',
        url: '/notifications/badges',
        icon: 'icon-bell'
      },
      {
        name: 'Modals',
        url: '/notifications/modals',
        icon: 'icon-bell'
      }
    ]
  },
  {
    name: 'Widgets',
    url: '/widgets',
    icon: 'icon-calculator',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  {
    divider: true
  },
  {
    title: true,
    name: 'Extras',
  },
  {
    name: 'Pages',
    url: '/pages',
    icon: 'icon-star',
    children: [
      {
        name: 'Login',
        url: '/login',
        icon: 'icon-star'
      },
      {
        name: 'Register',
        url: '/register',
        icon: 'icon-star'
      },
      {
        name: 'Error 404',
        url: '/404',
        icon: 'icon-star'
      },
      {
        name: 'Error 401',
        url: '/401',
        icon: 'icon-star'
      },
      {
        name: 'Error 500',
        url: '/500',
        icon: 'icon-star'
      }
    ]
  },
  {
    name: 'Disabled',
    url: '/dashboard',
    icon: 'icon-ban',
    badge: {
      variant: 'secondary',
      text: 'NEW'
    },
    attributes: { disabled: true },
  },
  {
    name: 'Download CoreUI',
    url: 'http://coreui.io/angular/',
    icon: 'icon-cloud-download',
    class: 'mt-auto',
    variant: 'success',
    attributes: { target: '_blank', rel: 'noopener' }
  },
  {
    name: 'Try CoreUI PRO',
    url: 'http://coreui.io/pro/angular/',
    icon: 'icon-layers',
    variant: 'danger',
    attributes: { target: '_blank', rel: 'noopener' }
  }
];


export class NavProvider {

  navList(): NavData[] {
    var nav = [];
    nav = nav.concat(navItems)
    //nav = nav.concat(tmplNavItems);
    return nav;
  }
}
