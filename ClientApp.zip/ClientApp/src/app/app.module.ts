import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, Injector, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER} from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { LocationStrategy, HashLocationStrategy, CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';


const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

import { AppComponent } from './app.component';

// Import containers
import { DefaultLayoutComponent } from './containers';

import { CfsLoginComponent } from './views/cfs-login/cfs-login.component';

import { P404Component } from './views/error/404.component';
import { P500Component } from './views/error/500.component';
import { LoginComponent } from './views/login/login.component';
import { RegisterComponent } from './views/register/register.component';

const APP_CONTAINERS = [
  DefaultLayoutComponent
];

import {
  AppAsideModule,
  AppBreadcrumbModule,
  AppHeaderModule,
  AppFooterModule,
  AppSidebarModule,
} from '@coreui/angular';

// Import routing module
import { AppRoutingModule } from './app.routing';

// Import 3rd party components
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ChartsModule } from 'ng2-charts';
/*loading-bar*/
import { LoadingBarRouterModule } from '@ngx-loading-bar/router';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
/*page spinner*/
import { NgxSpinnerModule } from "ngx-spinner";
/*toastr*/
import { ToastrModule } from 'ngx-toastr';
/*autocomplete fields*/
import {AutocompleteLibModule} from 'angular-ng-autocomplete';

/*http services*/
import { AppHttpInterceptor } from './app.interceptor';
import { CfsRouterService } from './services/cfs-router.service';
import { AccountService } from './services/account.service';
import { ReportUserService } from './services/report-user.service';
import { StaticSurveyService } from './services/static-survey.service';
import { NonIvrSurveyConfigService } from './services/non-ivr-survey-config.service';
import { AdminPanelService } from './services/admin-panel.service';

/*custom elements*/
import { ElementModule } from './elements/element.module';
import { ExcelService } from './utilities/excel.service';
import { NotifyService } from './utilities/notify.service';
import { ModalModule } from 'ngx-bootstrap';
import { LocalStorageService } from './services/local-storage.service';
import { P401Component } from './views/error/401.component';
import { AuthGuardService, PermissionGuardService } from './services/auth-guard.service';
import { IvrSurveyConfigService } from './services/ivr-survey-config.service';
import { P601Component } from './views/error/601.component';
import { DynamicSurveyService } from './services/dynamic-survey.service';
import { AppConfigService } from './services/app-config.service';


const initializerConfigFn = (appConfig: AppConfigService) => {
  return () => {
    return appConfig.loadAppConfig();
  };
};

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    
    AppRoutingModule,
    AppAsideModule,
    AppBreadcrumbModule.forRoot(),
    AppFooterModule,
    AppHeaderModule,
    AppSidebarModule,
    PerfectScrollbarModule,
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    ChartsModule,

    /*loading bar*/
    LoadingBarRouterModule,
    LoadingBarHttpClientModule,
    /*page spinner*/
    NgxSpinnerModule,
    /*toastr*/
    ToastrModule.forRoot(),
    /*autocomplete fields*/
    AutocompleteLibModule,
    /*modal*/
    ModalModule.forRoot(),



    /*custom elements*/
    ElementModule
  ],
  declarations: [
    AppComponent,
    ...APP_CONTAINERS,
    /*pages*/
    P404Component,
    P401Component,
    P500Component,
    P601Component,
    LoginComponent,
    CfsLoginComponent,
    RegisterComponent,   
  ],
  providers: [
    { provide: APP_INITIALIZER, useFactory: initializerConfigFn, multi: true, deps: [AppConfigService] },
    { provide: HTTP_INTERCEPTORS, useClass: AppHttpInterceptor, multi: true },
    LocalStorageService,
    CfsRouterService,
    AccountService,
    ReportUserService,
    AdminPanelService,
    StaticSurveyService,
    NonIvrSurveyConfigService,
    IvrSurveyConfigService,
    DynamicSurveyService,
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    ExcelService,
    NotifyService,
    AuthGuardService,
    PermissionGuardService
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],

  bootstrap: [ AppComponent ]
})
export class AppModule { 

}
