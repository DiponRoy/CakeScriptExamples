/*
https://blog.angularindepth.com/top-10-ways-to-use-interceptors-in-angular-db450f8a62d6
*/
import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, tap, catchError } from 'rxjs/operators';
import { ThemeService } from 'ng2-charts';

import { NotifyService } from './utilities/notify.service';
import { LocalStorageService } from './services/local-storage.service';
import { CfsRouterService } from './services/cfs-router.service';
import { AppConfigService } from './services/app-config.service';

@Injectable()
export class AppHttpInterceptor implements HttpInterceptor {
  /*Prod*/
  //baseUrl: string = "https://10.10.23.135:543/api"; 
  /*QA test*/
  //baseUrl: string = "https://10.10.19.147:544/api"; 
  /*Dev test*/
  //baseUrl: string = "https://10.10.19.147:644/api"; 
  /*dev*/
  // baseUrl: string = "https://localhost:44335/api";
  baseUrl: string = "";

  constructor(private readonly appConfig: AppConfigService, private storage: LocalStorageService, private router: CfsRouterService, private notify: NotifyService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (!/^(http|https):/i.test(req.url) && !req.url.startsWith('/assets/')) {
      this.baseUrl = this.appConfig.getApiBaseUrl();
    }

    const url = `${this.baseUrl}${req.url}`;
    const authorizationToken = `Bearer ${this.storage.getToken()}`;
    const apiReq = req.clone({
      url: url,
      setHeaders: {
        Authorization: authorizationToken
      }
    });

    //return next.handle(apiReq);
    return next.handle(apiReq).pipe(
      retry(0),
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
            this.router.sessionExpired();
            this.notify.warning("Unauthorized api access.");          
        }
        return throwError(error);
      })
    );
  }
}