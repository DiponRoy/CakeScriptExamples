export abstract class PermissionEnum {
    /*Report User*/
    public static ReportUserList: number                = 1;
    public static ReportUserUpload: number              = 2;
    public static ReportRole: number                    = 3;
    public static ReportUserDelegate: number            = 4;
    public static ReportUserHierarchy: number           = 5;
    public static ReportUserUserVsRole: number          = 6;
    public static ReportUserChannel: number             = 7;
    public static ReportUserChannelPartner: number      = 8;
    /*Admin User*/
    public static AdminUserList: number                 = 9;
    public static AdminUserRole: number                 = 10;
    public static AdminUserPage: number                 = 11;
    public static AdminUserVsRole: number               = 12;
    public static AdminUserRoleVsPage: number           = 13;
    /*Static Survey*/
    public static StaticSurveyChannel: number           = 14;
    public static StaticSurveyQuestionSetList: number   = 15;
    public static StaticSurveyQuestionSetModify: number = 16;
    /*Static Config*/
    public static SurveyConfigNonIvr: number            = 17;
    public static SurveyConfigIvr: number               = 18;
    /*Dynamic Survey List*/
    public static DynamicSurveyList: number            = 19;
}