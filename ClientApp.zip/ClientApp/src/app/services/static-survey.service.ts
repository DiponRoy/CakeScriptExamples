import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';


export interface QuestionSetChannel {
  id: string;
  details: string;
}

export interface QuestionSet {
    id: number
    title: string
    channelName: string,
    createDateTime: Date
}

export interface Question {
  questionId: number
  questionSetId: number
  questionNo: number
  childQuestionNo?: number
  questionType: string
  question: string
  questionBn: string
  hasChildQuestion: boolean
  parentQuestionNo?: number
  answerType: string
  entryTime: Date
}

export interface ChildQuestion extends Question {
  parentQuestionId: number
}

export interface SurveyQuestionHierarchy {
  parent: Question,
  child: Question
}

export interface QuestionAnswerOption {
  answerId: number
  questionSetId: number
  questionId: number
  answerOptionText: string
  answerOptionTextBn: string
  answerOptionRating: number
}




@Injectable({
  providedIn: 'root'
})
export class StaticSurveyService {

  constructor(private http: HttpClient) { }

  channels() : Observable<QuestionSetChannel[]> {
    return this.http.get<QuestionSetChannel[]>('/questionSetChannel');
  }

  createChannel(model: QuestionSetChannel) : Observable<QuestionSetChannel> {
    return this.http.post<QuestionSetChannel>('/questionSetChannel', model);
  }

  deleteChannel(id: string) : Observable<Object> {
    //return this.http.delete('/questionSetChannel/'+id);
    const model = {
      id: id
    };
    return this.http.post<object>('/questionSetChannel/delete', model);
  }

  

  questionSets() : Observable<QuestionSet[]> {
    return this.http.get<QuestionSet[]>('/questionSet');
  }

  createQuestionSet(model: QuestionSet) : Observable<QuestionSet> {
    return this.http.post<QuestionSet>('/questionSet', model);
  }

  questionSet(id: number) : Observable<QuestionSet> {
    return this.http.get<QuestionSet>('/questionSet/' +id);
  }

  updateQuestionSet(model: QuestionSet) : Observable<QuestionSet> {
    return this.http.put<QuestionSet>('/questionSet', model);
  }

  removeQuestionSet(id: number) : Observable<object> {
    const model = {
      id: id
    };
    return this.http.post<object>('/questionSet/delete', model);
  }



  questions(questionSetId: number) : Observable<Question[]> {
    return this.http.get<Question[]>('/question/questionSet/' +questionSetId);
  }
  createQuestion(model: Question) : Observable<Question> {
    return this.http.post<Question>('/question/', model);
  }
  createChildQuestion(model: ChildQuestion) : Observable<SurveyQuestionHierarchy> {
    return this.http.post<SurveyQuestionHierarchy>('/question/child', model);
  }
  updateQuestion(model: Question) : Observable<Question> {
    return this.http.put<Question>('/question/', model);
  }
  updateChildQuestion(model: ChildQuestion) : Observable<Question> {
    return this.http.put<Question>('/question/child', model);
  }
  removeQuestion(id: number) : Observable<SurveyQuestionHierarchy> {
    const model = {
      id: id
    };
    return this.http.post<SurveyQuestionHierarchy>('/question/delete', model);
  }



  answerOptions(questionSetId: number) : Observable<QuestionAnswerOption[]> {
    return this.http.get<QuestionAnswerOption[]>('/questionAnswerOption/questionSet/' +questionSetId);
  }
  createAnswerOption(model: QuestionAnswerOption) : Observable<QuestionAnswerOption> {
    return this.http.post<QuestionAnswerOption>('/questionAnswerOption', model);
  }
  updateAnswerOption(model: QuestionAnswerOption) : Observable<QuestionAnswerOption> {
    return this.http.put<QuestionAnswerOption>('/questionAnswerOption', model);
  }
  deleteAnswerOption(id: number) : Observable<object> {
    return this.http.delete<object>('/questionAnswerOption/'+id);
  }
  
  
}
