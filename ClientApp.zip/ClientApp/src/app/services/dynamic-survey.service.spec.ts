import { TestBed } from '@angular/core/testing';

import { DynamicSurveyService } from './dynamic-survey.service';

describe('DynamicSurveyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DynamicSurveyService = TestBed.get(DynamicSurveyService);
    expect(service).toBeTruthy();
  });
});
