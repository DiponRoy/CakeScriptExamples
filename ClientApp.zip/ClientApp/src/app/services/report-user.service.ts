import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ReportRole, ReportUserRole, ReportUser, ReportUserDelegate, ReportUserMonthlyHierarchy, ReportUserBulkUpload, ReportUserChannel, ReportUserChannelPartner} from '../models/report-user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportUserService {

  constructor(private http: HttpClient) { }

  channels() : Observable<ReportUserChannel[]> {
    return this.http.get<ReportUserChannel[]>('/userChannel');
  }

  createChannel(model: ReportUserChannel) : Observable<ReportUserChannel> {
    return this.http.post<ReportUserChannel>('/userChannel', model);
  }

  deleteChannel(id: string) : Observable<Object> {
    //return this.http.delete('/userChannel/'+id);
    const model = {
      id: id
    };
    return this.http.post<object>('/userChannel/delete', model);
  }



  channelPartners() : Observable<ReportUserChannelPartner[]> {
    return this.http.get<ReportUserChannelPartner[]>('/UserChannelPartner');
  }

  createChannelPartner(model: ReportUserChannelPartner) : Observable<ReportUserChannelPartner> {
    return this.http.post<ReportUserChannelPartner>('/UserChannelPartner', model);
  }

  deleteChannelPartner(id: number) : Observable<Object> {
    //return this.http.delete('/UserChannelPartner/'+id);
    const model = {
      id: id
    };
    return this.http.post<object>('/UserChannelPartner/delete', model);
  }



  roles() : Observable<ReportRole[]> {
    return this.http.get<ReportRole[]>('/role');
  }

  users() : Observable<ReportUser[]> {
    return this.http.get<ReportUser[]>('/user');
  } 

  uploadUsers(model: ReportUserBulkUpload) : Observable<Object> {
    return this.http.post<object>('/userDetail', model);
  } 

  createUserRoleMapp(model: ReportUserRole) : Observable<ReportUserRole> {
    return this.http.post<ReportUserRole>('/UserRole', model);
  }

  userRoleMapps() : Observable<ReportUserRole[]> {
    return this.http.get<ReportUserRole[]>('/userRole');
  } 

  deleteUserRoleMapp(mappId: number) : Observable<Object> {
    return this.http.delete('/UserRole/'+mappId);
  }

  createDelegation(model: ReportUserDelegate) : Observable<ReportUserDelegate> {
    return this.http.post<ReportUserDelegate>('/delegate', model);
  }

  delegations() : Observable<ReportUserDelegate[]> {
    return this.http.get<ReportUserDelegate[]>('/delegate');
  }

  deleteDelegation(id: number) : Observable<Object> {
    return this.http.delete('/delegate/'+id);
  }

  monthlyHierarchies(month: number, year: number) : Observable<ReportUserMonthlyHierarchy[]> {
    let params = new HttpParams();
    params = params.append('month', month.toString());
    params = params.append('year', year.toString());
    return this.http.get<ReportUserMonthlyHierarchy[]>('/Hierarchy', { params: params });
  }
}
