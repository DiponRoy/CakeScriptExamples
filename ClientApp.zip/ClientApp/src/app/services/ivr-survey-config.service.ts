import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';


export interface Ivr121 {
  resurveyDuration?: number;
  dialPerDay?: number;
  maxRightAnswer?: number;
  minVisitDuration?: number;
}

export interface Ussd121 {
  resurveyDuration?: number;
  dialPerDay?: number;
  maxRightAnswer?: number;
}

export interface MyGpSilentUser {
  resurveyDuration?: number;
  dialPerDay?: number;
  maxRightAnswer?: number;
}

export interface NetworkMeasurement {
  resurveyDuration?: number;
}

export interface Gpc {
  resurveyDuration?: number;
}

export interface Ipcc {
  resurveyDuration?: number;
}




@Injectable({
  providedIn: 'root'
})
export class IvrSurveyConfigService {

  constructor(private http: HttpClient) { }



  ivr123() : Observable<Ivr121> {
    return this.http.get<Ivr121>('/ivrSurveyConfig/ivr123');
  }
  createIvr123(model: Ivr121)  {
    return this.http.post('/ivrSurveyConfig/ivr123', model);
  }



  ussd123() : Observable<Ussd121> {
    return this.http.get<Ivr121>('/ivrSurveyConfig/ussd123');
  }
  createUssd123(model: Ussd121)  {
    return this.http.post('/ivrSurveyConfig/ussd123', model);
  }



  myGpSilentUser() : Observable<MyGpSilentUser> {
    return this.http.get<MyGpSilentUser>('/ivrSurveyConfig/MyGpSilentUser');
  }

  createMyGpSilentUser(model: MyGpSilentUser)  {
    return this.http.post('/ivrSurveyConfig/MyGpSilentUser', model);
  }


  networkMeasurement() : Observable<NetworkMeasurement> {
    return this.http.get<MyGpSilentUser>('/ivrSurveyConfig/NetworkMeasurement');
  }
  createNetworkMeasurement(model: NetworkMeasurement)  {
    return this.http.post('/ivrSurveyConfig/NetworkMeasurement', model);
  }


  gpc() : Observable<Gpc> {
    return this.http.get<Gpc>('/ivrSurveyConfig/Gpc');
  }
  createGpc(model: Gpc)  {
    return this.http.post('/ivrSurveyConfig/Gpc', model);
  }


  Ipcc() : Observable<Ipcc> {
    return this.http.get<Ipcc>('/ivrSurveyConfig/Ipcc');
  }
  createIpcc(model: Ipcc)  {
    return this.http.post('/ivrSurveyConfig/Ipcc', model);
  }

}