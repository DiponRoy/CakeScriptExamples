import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';


export interface AllDigitalChannelConfig
{
  resurveyDuration: number;
}

export interface FeedbackCallAndIvrChannelConfig
{
  conversationTimeSkip: number;
}



@Injectable({
  providedIn: 'root'
})
export class NonIvrSurveyConfigService {

  constructor(private http: HttpClient) { }

  allDigitalChannelConfig() : Observable<AllDigitalChannelConfig> {
    return this.http.get<AllDigitalChannelConfig>('/NonIvrSurveyConfig/AllDigitalChannel');
  }

  createAllDigitalChannelConfig(model: AllDigitalChannelConfig)  {
    return this.http.post('/NonIvrSurveyConfig/AllDigitalChannel', model);
  }



  feedbackCallAndIvrChannelConfig() : Observable<FeedbackCallAndIvrChannelConfig> {
    return this.http.get<FeedbackCallAndIvrChannelConfig>('/NonIvrSurveyConfig/FeedbackCallAndIvrChannel');
  }

  createFeedbackCallAndIvrChannelConfig(model: FeedbackCallAndIvrChannelConfig)  {
    return this.http.post('/NonIvrSurveyConfig/FeedbackCallAndIvrChannel', model);
  } 
}
