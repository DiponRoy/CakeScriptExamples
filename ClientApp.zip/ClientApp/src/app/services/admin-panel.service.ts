import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ReportRole, ReportUserRole, ReportUser, ReportUserDelegate, ReportUserMonthlyHierarchy, ReportUserBulkUpload, ReportUserChannel, ReportUserChannelPartner} from '../models/report-user.model';
import { Observable } from 'rxjs';


export interface AdminPanelUser {
  id: string
  name: string
  email: string
}
export interface AdminPanelUserUpdate extends AdminPanelUser {
  oldId: string
}

export interface AdminPanelPage {
  id: number
  displayName: string
  details: string
}

export interface AdminPanelRole {
  id: number
  name: string
  details: string
}

export interface AdminPanelUserVsRole {
  id: number
  userId: string
  roleId: number
}

export interface AdminPanelRoleVsPage {
  id: number
  pageId: number
  roleId: number
}

export interface AdminPanelRolePageModel {
  roleId: number
  pageIds: number[]
}


@Injectable({
  providedIn: 'root'
})
export class AdminPanelService {

  constructor(private http: HttpClient) { }

  users() : Observable<AdminPanelUser[]> {
    return this.http.get<AdminPanelUser[]>('/adminPanelUser');
  }
  createUser(model: AdminPanelUser) : Observable<AdminPanelUser> {
    return this.http.post<AdminPanelUser>('/adminPanelUser', model);
  }
  updateUser(model: AdminPanelUserUpdate) : Observable<AdminPanelUser> {
    return this.http.put<AdminPanelUser>('/adminPanelUser', model);
  }
  deleteUser(id: string) : Observable<Object> {
    //return this.http.delete('/adminPanelUser/'+id);
    const model = {
      id: id
    };
    return this.http.post('/adminPanelUser/Delete', model);
  }
  
  
  pages() : Observable<AdminPanelPage[]> {
    return this.http.get<AdminPanelPage[]>('/AdminPanelPage');
  }


  roles() : Observable<AdminPanelRole[]> {
    return this.http.get<AdminPanelRole[]>('/AdminPanelRole');
  }
  createRole(model: AdminPanelRole) : Observable<AdminPanelRole> {
    return this.http.post<AdminPanelRole>('/AdminPanelRole', model);
  }
  deleteRole(id: number) : Observable<Object> {
    //return this.http.delete('/AdminPanelRole/'+id);
    const model = {
      id: id
    };
    return this.http.post('/AdminPanelRole/Delete', model);
  }

  userRoleMapps() : Observable<AdminPanelUserVsRole[]> {
    return this.http.get<AdminPanelUserVsRole[]>('/AdminPanelUserRole');
  } 
  createUserRoleMapp(model: AdminPanelUserVsRole) : Observable<AdminPanelUserVsRole> {
    return this.http.post<AdminPanelUserVsRole>('/AdminPanelUserRole', model);
  }
  deleteUserRoleMapp(id: number) : Observable<Object> {
    return this.http.delete('/AdminPanelUserRole/'+id);
  }


  rolePageMapps(roleId: number) : Observable<AdminPanelRoleVsPage[]> {
    return this.http.get<AdminPanelRoleVsPage[]>('/AdminPanelRolePage/role/' +roleId);
  }
  upsertRolePageMapps(model: AdminPanelRolePageModel) : Observable<Object> {
    return this.http.post('/AdminPanelRolePage', model);
  }

}
