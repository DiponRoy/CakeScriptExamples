/*https://nbe.io/load-a-configuration-at-runtime-with-angular/*/

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


export interface AppConfig {
    apiBaseUrl:string
}

export class AppConfigModel implements AppConfig {
    apiBaseUrl:string
}


@Injectable({
  providedIn: 'root',
})
export class AppConfigService {
  appConfig:AppConfig = new AppConfigModel();

  constructor(private http: HttpClient) {}

  loadAppConfig() {
    debugger;
    return this.http
    .get('/assets/config.app.json')
    .toPromise()
    .then(data => { 
        this.appConfig = data as AppConfig;
      })
    .catch(error => { 
        console.log("error to load config.app.json:" +error); 
      });
  }

  getApiBaseUrl(): string {
    debugger;
    return this.appConfig.apiBaseUrl;
  }
}