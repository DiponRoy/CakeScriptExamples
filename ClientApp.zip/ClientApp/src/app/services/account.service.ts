import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

/*=> api models*/
export interface TokenRequest {
  userName: string;
  password: string;
}
export interface TokenResponse {
  token: string;
}
export interface LoginUserDetail {
  userName: string;
  email: string;
}
export interface Permission {
  id: number
  displayName: string
  details: string
}
/*<= api models*/

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http: HttpClient) { }


  token(model: TokenRequest) : Observable<TokenResponse> {
    return this.http.post<TokenResponse>('/account/token', model);
  }

  currentUser() : Observable<LoginUserDetail> {
    return this.http.get<LoginUserDetail>('/account/userDetails');
  }

  permissions() : Observable<Permission[]> {
    return this.http.get<Permission[]>('/account/Permissions');
  }
}
