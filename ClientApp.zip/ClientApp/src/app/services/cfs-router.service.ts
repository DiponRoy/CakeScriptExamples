import { Injectable } from '@angular/core';
import { Router } from '@angular/router';



@Injectable({
  providedIn: 'root'
})
export class CfsRouterService {

  constructor(private router: Router) { }

  reportUserUpload() {
    const url = "/report-user/users-upload";
    this.router.navigate([url]);     
  }
  reportUsers() {
    const url = "/report-user/users";
    this.router.navigate([url]);     
  }

  viewQuestionSet(questionSetId: number) {
    const url = "/static-survey/question-set-details";
    this.router.navigate([url], { queryParams: { id: questionSetId }});     
  }
  viewQuestionSets() {
    const url = "/static-survey/question-sets";
    this.router.navigate([url]);     
  }


  viewDynamicSurveys() {
    const url = '/dynamic-survey/dynamicsurveylist';
    this.router.navigate([url]);
  }
 

  dashboard() {
    const url = '/app-dashboard';
    this.router.navigate([url]);
  }

  login() {
    const url = '/app-login';
    this.router.navigate([url]);
  }

  sessionExpired() {
    const url = '/401';
    this.router.navigate([url]);
  }

  noPermission() {
    const url = '/601';
    this.router.navigate([url]);
  }
}
