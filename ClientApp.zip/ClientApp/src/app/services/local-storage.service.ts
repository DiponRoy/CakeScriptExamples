import { Injectable, EventEmitter } from '@angular/core';
import { LoginUserDetail } from './account.service';


export class CurrentUserModel implements LoginUserDetail {
  userName: string;
  email: string;
}

@Injectable()
export class LocalStorageService {

  tokenKey:string = "token";
  currentUserKey:string = "currentUser";
  permissionKey:string = "permissions";


  get(key: string): any {
    var value = localStorage.getItem(key)
    return value ? value : null;
  }

  json(model: any): string {
    var value = JSON.stringify(model);
    return value;
  }

  js<T>(value: string): T {
    var model: T = <T>JSON.parse(value);
    return model;
  }

  public setPermissions(list: number[]) {
    localStorage.setItem(this.permissionKey, this.json(list));
  }

  public getPermissions(): number[] {
    const value = this.get(this.permissionKey);
    if(value == null){
      return null;
    }
    const result = this.js<number[]>(value);
    return result;
  }



  public setCurrentUser(model: CurrentUserModel) {
    localStorage.setItem(this.currentUserKey, this.json(model));
  }

  public getCurrentUser(): CurrentUserModel {
    const value = this.get(this.currentUserKey);
    if(value == null){
      return null;
    }
    const result = this.js<CurrentUserModel>(value);
    return result;
  }



  public setToken(token: string) {
    localStorage.setItem(this.tokenKey, token);
  }

  public getToken(): string {
    const value = this.get(this.tokenKey);
    const result = value === null ? '' : <string>value;
    return result;
  }

  public clear() {
    localStorage.clear();
  }
}
