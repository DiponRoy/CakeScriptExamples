/*
Auth Guard:
https://medium.com/@ryanchenkie_40935/angular-authentication-using-route-guards-bf7a4ca13ae3
https://www.techiediaries.com/angular-jwt/


Role Guard:
https://stackoverflow.com/questions/42719445/pass-parameter-into-route-guard

Mulitple Guard:
https://stackoverflow.com/questions/43893314/angular-4-multiple-guards-execution-sequence
*/

import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, ActivatedRoute, RouterStateSnapshot } from '@angular/router';
import { LocalStorageService } from './local-storage.service';
import { CfsRouterService } from './cfs-router.service';

@Injectable()
export class AuthGuardService implements CanActivate {

  constructor(private storage: LocalStorageService, private router: CfsRouterService) {}
  
  canActivate(): boolean {
    if (this.storage.getToken() === '') {
      this.router.sessionExpired();
      return false;
    }
    return true;
  }
}

/*
import { PermissionGuardService as PermissionGuard } from '../../services/auth-guard.service';

canActivate: [PermissionGuard],
data: {
  permissions: [PermissionEnum.ReportUserList],
}
*/
@Injectable()
export class PermissionGuardService implements CanActivate {

  constructor(private storage: LocalStorageService, private router: CfsRouterService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let hasPermission: boolean = false;
    try {
      var expectedPermissions = route.data["permissions"] as Array<number>;
      var permissions = this.storage.getPermissions();
      var commons = expectedPermissions.filter(x => permissions.some(p => x === p ));
      hasPermission = commons.length > 0;
    } catch {
      hasPermission = false;
    }

    if(!hasPermission){
      this.router.noPermission();
    }
    return hasPermission;
  }
}