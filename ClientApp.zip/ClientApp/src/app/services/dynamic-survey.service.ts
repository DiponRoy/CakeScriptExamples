import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { DynamicSurvey } from '../models/dynamic-survey';
import { map, tap, catchError } from 'rxjs/operators';
import { DynamicSurveyMsisdn, DynamicSurveyMsisdnUpload } from '../models/dynamic-survey-msisdn';
import { SurveyQuestion } from '../models/survey-question';
import { DynamicSurveyModel } from '../views/dynamic-survey/dynamicsurveylist/dynamicsurveylist.component';
import { CFSResponse } from '../models/cfsresponse';


export interface DynamicSurveyDail {
  surveyId: number,
  msisdn: string,
  dialStatus: string,      /*1: done*/
  dailDateTimeString: string,    /*YYYY/MM/DD hh:mm:ss*/
  q1Answer: string,
  q2Answer: string,
  q3Answer: string,
  q4Answer: string,
  q5Answer: string,
  dailDateTime?: Date
}

@Injectable({
  providedIn: 'root'
})
export class DynamicSurveyService {
  private baseApiUrl: string;
  private apiDownloadUrl: string;
  private apiUploadUrl: string;
  private apiFileUrl: string;
  private apiDeleteUrl: string;

  constructor(private http: HttpClient) { 
    this.baseApiUrl = '/uploaddownload/';
    this.apiDownloadUrl = this.baseApiUrl + 'download';
    this.apiUploadUrl = this.baseApiUrl + 'upload';
    this.apiFileUrl = this.baseApiUrl + 'files';
    this.apiDeleteUrl = this.baseApiUrl + 'delete';
  }

  createSurvey(model: DynamicSurveyModel) : Observable<CFSResponse> {

    // alert(model.startDateTime);
    return this.http.post<CFSResponse>('/DynamicSurvey', model);
  }

  forcestop(model: DynamicSurvey) : Observable<CFSResponse> {
    return this.http.post<CFSResponse>('/DynamicSurveyForceStop', model);
  }

  createPhpfile(model: SurveyQuestion[]) : Observable<CFSResponse> {
    return this.http.post<CFSResponse>('/DynamicSurveyQuestion', model);
  }

  getAllDynamicSurvey() : Observable<DynamicSurvey[]> {
    return this.http.get<DynamicSurvey[]>('/DynamicSurvey');
  }

  getDynamicSurveyById(surveyId:Number) : Observable<DynamicSurvey> {
    return this.http.get<DynamicSurvey>('/DynamicSurvey/DynamicSurveyById/'+ surveyId).pipe(
      tap(_ => console.log(`fetched getsurveydetail id=${surveyId}`)),
      catchError(this.handleError<DynamicSurvey>(`getsurveydetail id=${surveyId}`)));
  }
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
  
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
  
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  postmsisdnforsurvey(model: DynamicSurveyMsisdnUpload) : Observable<Object> {
    return this.http.post<object>('/DynamicSurveyMSISDN', model);
  } 

 getDynamicSurveyQuestion(id: number) : Observable<SurveyQuestion[]> {
  return this.http.get<SurveyQuestion[]>('/DynamicSurveyQuestion/'+ id);
 }

 public uploadFile(file: Blob,item: any): Observable<HttpEvent<void>> {
  
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append( item.surveyId,'surveyId');
  formData.append(item.questionId,'fileName');
  formData.append(item.optionNo,'optionNo');

  return this.http.request(new HttpRequest(
    'POST',
    this.apiUploadUrl,
    formData,
    {
      reportProgress: true
    }));
}


public downloadFile(item: SurveyQuestion): Observable<HttpEvent<Blob>> {
  return this.http.request(new HttpRequest(
    'GET',
    `${this.apiDownloadUrl}?file=${item.questionId}&sruveyId=${item.surveyId}`,
    null,
    {
      reportProgress: true,
      responseType: 'blob'
    }));
}

public deleteFile(item: SurveyQuestion): Observable<HttpEvent<Blob>> {
  return this.http.request(new HttpRequest(
    'POST',
    `${this.apiDeleteUrl}?file=${item.questionId}&sruveyId=${item.surveyId}`,
    null,
    {
      reportProgress: true,
      responseType: 'blob'
    }));
}

  DoneDails(surveyId: number) : Observable<DynamicSurveyDail[]> {
    return this.http.get<DynamicSurveyDail[]>('/DynamicSurveyDial/GetDonesBySurvey/' + surveyId);
  }
  ExportMSISDNBySurveyId(surveyId: number) : Observable<DynamicSurveyMsisdn[]> {
    return this.http.get<DynamicSurveyMsisdn[]>('/DynamicSurveyMSISDN/ExportMSISDNBySurveyId/' + surveyId);
  }
  // deleteSurveyMSISDNBySurveyId(surveyId: number):Observable<CFSResponse> {
  //   return this.http.delete<CFSResponse>('/DynamicSurveyMSISDN/DeleteAllMSISDNBySurveyId/'+ surveyId);
  // }
}
