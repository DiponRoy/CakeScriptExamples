import { CFSResponse } from './cfsresponse';

describe('CFSResponse', () => {
  it('should create an instance', () => {
    expect(new CFSResponse()).toBeTruthy();
  });
});
