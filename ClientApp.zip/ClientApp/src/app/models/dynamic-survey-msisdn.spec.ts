import { DynamicSurveyMsisdn } from './dynamic-survey-msisdn';

describe('DynamicSurveyMsisdn', () => {
  it('should create an instance', () => {
    expect(new DynamicSurveyMsisdn()).toBeTruthy();
  });
});
