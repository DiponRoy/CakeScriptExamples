import { SurveyQuestion } from './survey-question';

describe('SurveyQuestion', () => {
  it('should create an instance', () => {
    expect(new SurveyQuestion()).toBeTruthy();
  });
});
