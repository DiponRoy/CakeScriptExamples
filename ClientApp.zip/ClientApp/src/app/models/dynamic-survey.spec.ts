import { DynamicSurvey } from './dynamic-survey';

describe('DynamicSurvey', () => {
  it('should create an instance', () => {
    expect(new DynamicSurvey()).toBeTruthy();
  });
});
