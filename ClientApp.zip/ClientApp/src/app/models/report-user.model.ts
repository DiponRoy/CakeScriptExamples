/*api models =>*/
export interface ReportUserChannel {
    id: string;
    details: string;
}

export interface ReportUserChannelPartner {
    id: number;
    channelId: string;
    partnerName: string;
    details: string;
}

export interface ReportRole {
    id: number;
    name: string;
}

export interface ReportUser {
    id: string;
    channelName: string;
    partnerGpcName: string;
    empName: string;
    empEmail: string;
    designation: string;
    isSupervisor: boolean;
    supervisorDomainName: string;

    empId: string;  /*optional*/
}

export interface ReportUserDetail {
    user: ReportUser;
    roles: ReportRole[];
    deletationToUsers: ReportUser[];
}

export interface ReportUserBulkUpload {

    sourceDetail: string;
    month: number;
    year: number;
    users: ReportUser[];
}

export interface ReportUserRole {
    id: number;
    userDomainId: string;
    roleId: number;
}

export interface ReportUserDelegate {
    id: number;
    delegateForm: string;
    delegateTo: string;
}

export interface ReportUserMonthlyHierarchy {
    controlDateMonth: number;
    controlDateYear: string;
    agentId: string;
    empName: string;
    empEmail: string;
    channelName: string;
    partnerGpcName: string;
    empId: string;
    designation: string;
    isSupervisor: boolean;
    level1: string;
    level2: string;
    level3: string;
    level4: string;
    level5: string;
    level6: string;
    level7: string;
}
/*api models <=*/

 

export class ReportUserModel implements ReportUser {
    id: string;
    channelName: string;
    partnerGpcName: string;
    empName: string;
    empEmail: string;
    isSupervisor: boolean;
    supervisorDomainName: string;
    designation: string;
    empId: string;  /*optional*/
} 

export class ReportRoleModel {
    id: number;
    name: string;
} 


/*models*/
export class DelegationModel implements ReportUserDelegate {
    id: number
    delegateForm: string = "";
    delegateTo: string = "";
} 

export class UserVsRoleViewModel implements ReportUserRole{
    id: number;
    userDomainId: string = "";
    roleId: number;
    roleName: string = "";
 }

export class MonthlyHierarchyModel {
    // controlDateMonth: number;
    // controlDateYear: string;
    agentId: string = "";
    // channelName: string;
    // empName: string;
    // empEmail: string;
    // partnerGpcName: string;
    // empId: string;
    // isSupervisor: boolean;
    // level1: string;
    // level2: string;
    // level3: string;
    // level4: string;
    // level5: string;
    // level6: string;
    // level7: string;
}

/*=> view models*/
export class UserListViewModel implements ReportUserDetail {
    separator: string = ', ';
    user: ReportUser = new ReportUserModel();
    roles: ReportRole[] = [];
    deletationToUsers: ReportUser[] = [];

    roleNameListString(): string {
        var value = this.roles.map(x => x.name).join(this.separator)
        return value;
    }
    deletationToUserIdListString(): string {
        var value = this.deletationToUsers.map(x => x.id).join(this.separator)
        return value;
    }
}

/*File export models*/
export interface UserExportImport {
    EmployeeId: string;
    DomainId: string;
    ChannelName: string;
    PartnerName: string;
    Name: string;
    Email: string;
    Designation: string;
    IsSupervisor: boolean;
    SupervisorDomainId: string;

    Roles: string;
    DelegationToUsers: string;
}

export class UserExportImportModel implements UserExportImport {
    EmployeeId: string;
    DomainId: string;
    ChannelName: string;
    PartnerName: string;
    Name: string;
    Email: string;
    Designation: string;
    IsSupervisor: boolean;
    SupervisorDomainId: string;

    Roles: string;
    DelegationToUsers: string;

    set(x: UserListViewModel): void {
        this.DomainId = x.user.id;
        this.ChannelName = x.user.channelName;
        this.PartnerName = x.user.partnerGpcName;
        this.Name = x.user.empName;
        this.Email = x.user.empEmail;
        this.EmployeeId = x.user.empId;
        this.Designation = x.user.designation;
        this.IsSupervisor = x.user.isSupervisor;
        this.SupervisorDomainId = x.user.supervisorDomainName;
        this.Roles = x.roleNameListString();
        this.DelegationToUsers = x.deletationToUserIdListString();
    }

    // setFromModel(model: UserExportImport) {
    //     this.DomainId = model.DomainId.toString().trim();
    //     this.ChannelName = model.ChannelName.toString().trim();
    //     this.PartnerName = model.PartnerName.toString().trim();
    //     this.Name = model.Name.toString().trim();
    //     this.Email = model.Email.toString().trim();
    //     this.EmployeeId = model.EmployeeId.toString().trim();
    //     this.Designation = model.Designation.toString().trim();
    //     this.IsSupervisor = model.IsSupervisor;
    //     this.SupervisorDomainId = model.SupervisorDomainId.toString().trim();
    //     this.Roles = model.Roles;
    //     this.DeletationToUsers = model.DeletationToUsers;
    // }

    private hasValue<T>(value: T): boolean {
        var result = value != undefined && value != null;
        return result
    }

    setFromModel(model: UserExportImport) {
        this.DomainId =             this.hasValue(model.DomainId) ? model.DomainId.toString().trim() : "";
        this.ChannelName =          this.hasValue(model.ChannelName) ? model.ChannelName.toString().trim() : "";
        this.PartnerName =          this.hasValue(model.PartnerName) ? model.PartnerName.toString().trim() : "";
        this.Name =                 this.hasValue(model.Name) ? model.Name.toString().trim() : "";
        this.Email =                this.hasValue(model.Email) ? model.Email.toString().trim() : "";
        this.EmployeeId =           this.hasValue(model.EmployeeId) ? model.EmployeeId.toString().trim() : "";
        this.Designation =          this.hasValue(model.Designation) ? model.Designation.toString().trim() : "";
        this.IsSupervisor =         this.hasValue(model.Designation) ? model.IsSupervisor : null;
        this.SupervisorDomainId =   this.hasValue(model.SupervisorDomainId) ? model.SupervisorDomainId.toString().trim() : "";
        this.Roles =                this.hasValue(model.Roles) ? model.Roles : "";
        this.DelegationToUsers =    this.hasValue(model.DelegationToUsers) ? model.DelegationToUsers : "";
    }

    get(): UserListViewModel {
        const x = new UserListViewModel();
        x.user.empId = this.EmployeeId;
        x.user.id = this.DomainId;
        x.user.channelName = this.ChannelName;
        x.user.partnerGpcName = this.PartnerName;
        x.user.empName = this.Name;
        x.user.empEmail = this.Email;
        x.user.empId = this.EmployeeId;
        x.user.designation = this.Designation;
        x.user.isSupervisor = this.IsSupervisor;
        x.user.supervisorDomainName = this.SupervisorDomainId;

        // roles: ReportRole[]
        // x.roles = [];
        // this.Roles = this.Roles == undefined || this.Roles == null ? '' : this.Roles;
        // this.Roles.split(x.separator)   
        // .forEach(name => {
        //     var foundRoles = roles.filter(r => r.name === name);
        //     var m = new ReportRoleModel();
        //     m.id = foundRoles.length === 0 ? 0 : foundRoles[0].id;
        //     m.name = name;
        //     x.roles.push(m);
        // });

        // x.deletationToUsers = [];
        // this.DeletationToUsers = this.DeletationToUsers == undefined || this.DeletationToUsers == null ? '' : this.DeletationToUsers;
        // this.DeletationToUsers.split(x.separator)   
        // .forEach(name => {
        //     var m = new ReportUserModel();
        //     m.id = name;
        //     x.deletationToUsers.push(m);
        // });
        
        return x;
    }
}

/*<= view models*/