export class SurveyQuestion {
    surveyId: number;
        questionId: string;
        optionNo: number;
        audioFileName?: any;
        audioFileType?: any;
}
