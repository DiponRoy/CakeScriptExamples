import { DynamicSurvey } from './dynamic-survey';

export class CFSResponse {
        statusCode?: any;
        statusMessage?: any;
        dynamicSurvey: DynamicSurvey;
}
