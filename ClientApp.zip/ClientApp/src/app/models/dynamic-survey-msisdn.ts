export class DynamicSurveyMsisdn {
    surveyId: number;
    msisdn: string;
    attribute1?: any;
    attribute2?: any;
    attribute3?: any;
}


export interface DynamicSurveyMsisdnUpload {
    surveyId: number;
    msisdns: DynamicSurveyMsisdn[];
}