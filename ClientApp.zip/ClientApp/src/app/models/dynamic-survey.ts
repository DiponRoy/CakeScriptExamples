export class DynamicSurvey {
    id: number;
    name?: any;
    questionNo: number;
    startDateTime: Date;
    endDateTime: Date;
    actualStartDateTime: Date;
    actualEndDateTime: Date;
    status: number;
}

export interface ProgressStatus {
    status: ProgressStatusEnum;
    percentage?: number;
  }
  
  export enum ProgressStatusEnum {
    START, COMPLETE, IN_PROGRESS, ERROR
  }
