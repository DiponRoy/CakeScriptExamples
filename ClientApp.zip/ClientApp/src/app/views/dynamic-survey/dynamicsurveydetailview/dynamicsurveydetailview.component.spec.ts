import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicsurveymsisdnuploadComponent } from './dynamicsurveymsisdnupload.component';

describe('DynamicsurveymsisdnuploadComponent', () => {
  let component: DynamicsurveymsisdnuploadComponent;
  let fixture: ComponentFixture<DynamicsurveymsisdnuploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicsurveymsisdnuploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicsurveymsisdnuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
