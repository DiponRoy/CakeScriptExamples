import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RxFormBuilder } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { ReportUserService } from '../../../services/report-user.service';
import { DynamicSurvey } from '../../../models/dynamic-survey';
import * as XLSX from 'xlsx';
import { DynamicSurveyMsisdn } from '../../../models/dynamic-survey-msisdn';
import { DynamicSurveyService } from '../../../services/dynamic-survey.service';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { DateTimeHelper } from '../../../utilities/dateTime.helper';
import * as moment from 'moment';
import { SurveyQuestion } from '../../../models/survey-question';
import { HttpEventType } from '@angular/common/http';
import { ExcelService } from '../../../utilities/excel.service';
import { DynamicSurveyDail } from '../../../services/dynamic-survey.service';

export class SurveyDialExport {
  Msisdn: string;
  DailedDate: string;
  Q1Answer: string;
  Q2Answer: string;
  Q3Answer: string;
  Q4Answer: string;
  Q5Answer: string;

  public set(model: DynamicSurveyDail) {
    this.Msisdn = model.msisdn;
    this.DailedDate = model.dailDateTimeString;
    this.Q1Answer = model.q1Answer;
    this.Q2Answer = model.q2Answer;
    this.Q3Answer = model.q3Answer;
    this.Q4Answer = model.q4Answer;
    this.Q5Answer = model.q5Answer;
  }
}

@Component({
  selector: 'app-dynamicsurveydetailview',
  templateUrl: './dynamicsurveydetailview.component.html',
  styleUrls: ['./dynamicsurveydetailview.component.scss']
})
export class DynamicsurveydetailviewComponent implements OnInit {

  createForm: FormGroup;
  selecteddynamicsurvey: DynamicSurvey;
  list: SurveyQuestion[] = [];  
  dynamicSurveyDetail: DynamicSurvey = { id: 0, status:0, name:'', startDateTime:null, endDateTime:null,questionNo:0,actualStartDateTime:null,actualEndDateTime:null };
  
  constructor(private route: ActivatedRoute, private service: DynamicSurveyService, private router: Router , private notify: NotifyService, private excelService: ExcelService) {
    
   }
  

  ngOnInit() {
    this.notify.blockUi();
    let surveyId = JSON.parse(localStorage.getItem('selecteddynamicsurveyId') || '{}');
    if(surveyId>0){
      this.getSurveyDetails(surveyId);
      this.getSurveyQuestionBySurveyId(surveyId);
    }
    else{
      this.dynamicSurveyDetail=null;
      alert("No Data Found");
    }
  this.notify.blockUi(false);
    
  }
  exportDailList(item: DynamicSurvey) {
    this.notify.blockUi();
    this.service.DoneDails(item.id)
    .subscribe((data) => {
      var list: SurveyDialExport[] = [];
      data.forEach(x => {
        var model = new SurveyDialExport();
        model.set(x);
        if(x.dailDateTime != null) {
          model.DailedDate = DateTimeHelper.dateTimeString(x.dailDateTime)
        }
        list.push(model);
      })
      this.excelService.exportAsExcelFile(list, 'Survey_Dailed_List');  
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Unable to get dailed list.");
      this.notify.blockUi(false);
    });
  }
  getSurveyQuestionBySurveyId(Id:any){
    this.service.getDynamicSurveyQuestion(Id).subscribe(res => {
      this.list = res;      
      });
  }
  getSurveyDetails(id: any) {
    this.service.getDynamicSurveyById(id)
      .subscribe((data: any) => {
        this.dynamicSurveyDetail = data;              
      });
  }

  dateTimeString(dateTime: Date): string {
    let value: string = '';
    if(dateTime){
      value = moment(dateTime).format("DD-MMM,YYYY hh:mm A");
    }    
    return value;
  }
  public download(item: SurveyQuestion) {
    
    //this.downloadStatus.emit( {status: ProgressStatusEnum.START});
    //this.notify.blockUi();
    this.service.downloadFile(item).subscribe(
      data => {
        switch (data.type) {
          case HttpEventType.DownloadProgress:
         // this.notify.blockUi(false);
            //this.downloadStatus.emit( {status: ProgressStatusEnum.IN_PROGRESS, percentage: Math.round((data.loaded / data.total) * 100)});
            break;
          case HttpEventType.Response:
            //this.downloadStatus.emit( {status: ProgressStatusEnum.COMPLETE});
            const downloadedFile = new Blob([data.body], { type: data.body.type });
            const a = document.createElement('a');
            a.setAttribute('style', 'display:none;');
            document.body.appendChild(a);
            a.download = item.questionId;
            a.href = URL.createObjectURL(downloadedFile);
            a.target = '_blank';
            a.click();
            document.body.removeChild(a);
            //this.notify.blockUi(false);
            break;
            
        }
      },
      error => {
       // this.downloadStatus.emit( {status: ProgressStatusEnum.ERROR});
      }
      
    );
  }
  exxportExcel() {
    this.notify.blockUi();
    this.service.ExportMSISDNBySurveyId(this.dynamicSurveyDetail.id)
    .subscribe((data) => {
      var expList: DynamicSurveyMsisdn[] = [];
      data.forEach(x => {
        
        expList.push(x);
      })
      this.excelService.exportAsExcelFile(expList, 'Survey_Dailed_List');  
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Unable to get dailed list.");
      this.notify.blockUi(false);
    });
  }

}
