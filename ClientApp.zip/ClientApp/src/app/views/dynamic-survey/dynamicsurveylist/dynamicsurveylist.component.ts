import { Component, OnInit } from '@angular/core';
import { RxFormBuilder, required, prop, date } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { DynamicSurveyService, DynamicSurveyDail } from '../../../services/dynamic-survey.service';
import { DynamicSurvey } from '../../../models/dynamic-survey';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';
import { CFSResponse } from '../../../models/cfsresponse';
import { BsDatepickerViewMode } from 'ngx-bootstrap/datepicker/models';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import * as moment from 'moment';
import { ExcelService } from '../../../utilities/excel.service';
import { DateTimeHelper } from '../../../utilities/dateTime.helper';

export class DynamicSurveyModel {
  // @prop()
  // id: number;
  @required()
  name?: any;
  @required()
  questionNo: number;
  @prop()
  startDateTime: Date;
  @prop()
  endDateTime: Date;

  @required()
  startDate: Date = null;
  @required()
  endDate: Date = null;

  @required()
  startTime: Date = null;
  @required()
  endTime: Date = null;

  // @prop()
  // actualStartDateTime: Date;
  // @prop()
  // actualEndDateTime: Date;
  // @prop()
  // status: number;
}

export class SurveyDialExport {
  Msisdn: string;
  DailedDate: string;
  Q1Answer: string;
  Q2Answer: string;
  Q3Answer: string;
  Q4Answer: string;
  Q5Answer: string;

  public set(model: DynamicSurveyDail) {
    this.Msisdn = model.msisdn;
    this.DailedDate = model.dailDateTimeString;
    this.Q1Answer = model.q1Answer;
    this.Q2Answer = model.q2Answer;
    this.Q3Answer = model.q3Answer;
    this.Q4Answer = model.q4Answer;
    this.Q5Answer = model.q5Answer;
  }
}

@Component({
  selector: 'app-dynamicsurveylist',
  templateUrl: './dynamicsurveylist.component.html',
  styleUrls: ['./dynamicsurveylist.component.scss']
})
export class DynamicsurveylistComponent implements OnInit {
  dpConfig: Partial<BsDatepickerConfig>;
  minDate: Date = new Date();
  startDate: Date;
  endDate: Date;
  startTime: Date = new Date();
  endTime: Date = new Date();
  
  list: DynamicSurvey[] = [];
  searchName: string = "";
  createModel: DynamicSurveyModel = new DynamicSurveyModel();
  createForm: FormGroup;

  constructor(private formBuilder: RxFormBuilder
    , private service: DynamicSurveyService
    , private notify: NotifyService
    , private _router: Router
    , private excelService: ExcelService) {
      this.createForm = this.formBuilder.formGroup(this.createModel);  
  }

  cfsresponse: CFSResponse;
  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  startDateChange(): void {
    this.createForm.controls.startDate.setValue(this.startDate);
    this.createForm.controls.startDate.markAsDirty();
    //alert(this.startDate);
  }
  endDateChange(): void {
    this.createForm.controls.endDate.setValue(this.endDate);
    this.createForm.controls.endDate.markAsDirty();
    //alert(this.endDate);
  }
  startTimeChange(): void {
    //alert(this.startTime);
    this.createForm.controls.startTime.setValue(this.startTime);
    this.createForm.controls.startTime.markAsDirty();
  }
  endTimeChange(): void {
   // alert(this.endTime);
    this.createForm.controls.endTime.setValue(this.endTime);
    this.createForm.controls.endTime.markAsDirty();
    //alert(this.formatDate(this.endTime));
  }

  dateTimeString(dateTime: Date): string {
    let value: string = '';
    if(dateTime){
      value = moment(dateTime).format("DD-MMM,YYYY hh:mm A");
    }    
    return value;
  }

  ngOnInit() {
    /*datepicker*/
    let minMode: BsDatepickerViewMode = 'day';
    this.dpConfig = Object.assign({}, {
      minMode : minMode,
      dateInputFormat: 'DD-MMM, YYYY'
    });


    this.notify.blockUi();
    this.loadingDataGrid();
      
  }


  searchedItems(): DynamicSurvey[] {
    const values = this.list.filter(x =>
      x.name.toLowerCase().includes(this.searchName.toLowerCase())
    );
    return values;
  }

  assignmsisdn(item: DynamicSurvey) {

    localStorage.setItem('selecteddynamicsurveyassignmsisdn', JSON.stringify(item));
    this._router.navigate(['dynamic-survey/dynamicsurveymsisdnupload']);
    
  }

  assignaudio(item: DynamicSurvey) {
    localStorage.setItem('selecteddynamicsurveyassignaudio', JSON.stringify(item));
    this._router.navigate(['dynamic-survey/dynamicsurveyaudiofileupload']);
  }
  loadingDataGrid(){
    this.notify.blockUi();
          this.service.getAllDynamicSurvey().subscribe((data) => {
            this.list = data;
            this.notify.blockUi(false);
          },
            error => {
              this.notify.error("Unable to load channels.");
              this.notify.blockUi(false);
            });
  }
  detailview(item:DynamicSurvey){
    localStorage.setItem('selecteddynamicsurveyId', JSON.stringify(item.id));
    this._router.navigate(['dynamic-survey/dynamicsurveydetailview']);    
  }
  forcestop(item: DynamicSurvey) {
    // alert("bainchod....");
    this.notify.blockUi();
    this.service.forcestop(item)
      .subscribe((data) => {
        this.cfsresponse = data;
        if (this.cfsresponse.statusCode==='200') {
          // this.list.push(data.dynamicSurvey);
         this.notify.success(this.cfsresponse.statusMessage);
          // FormHelper.clean(this.createForm);
          this.notify.blockUi(false);
          this.loadingDataGrid();
        } else {
          this.notify.warning(this.cfsresponse.statusMessage);
          this.notify.blockUi(false);
        }
        
      },
        error => {
          // if (HttpHelper.isValidationError(error)) {
          //   FormHelper.mappValidationErrors(this.createForm, error)
          // } else {
          //   this.notify.error("Unable to create channel.");
          // }
          this.notify.blockUi(false);
        });
  }

  exportDailList(item: DynamicSurvey) {
    this.notify.blockUi();
    this.service.DoneDails(item.id)
    .subscribe((data) => {
      var list: SurveyDialExport[] = [];
      data.forEach(x => {
        var model = new SurveyDialExport();
        model.set(x);
        if(x.dailDateTime != null) {
          model.DailedDate = DateTimeHelper.dateTimeString(x.dailDateTime)
        }
        list.push(model);
      })
      this.excelService.exportAsExcelFile(list, 'Survey_Dailed_List');  
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Unable to get dailed list.");
      this.notify.blockUi(false);
    });
  }


  public formatDate(today: Date) {
    return today.toString().substr(0, 10);
}

  create() {
    // this.startTimeChange();
    // this.endTimeChange();

    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    let startDate: Date = this.createForm.controls.startDate.value;
    let startTime: Date  = this.createForm.controls.startTime.value;
    
    //startDate.setTime(startTime.getTime());
    startDate.setHours(startTime.getHours());

   // alert(this.formatDate(this.startDate));
    startDate.setMinutes(startTime.getMinutes());

    

    //alert(this.formatDate(this.startDate));

    this.createForm.controls.startDateTime.setValue(startDate);
    let endDate: Date = this.createForm.controls.endDate.value;
    let endTime: Date  = this.createForm.controls.endTime.value;

    //endDate.setTime(endTime.getTime());
    endDate.setHours(endTime.getHours());
    endDate.setMinutes(endTime.getMinutes());

    this.createForm.controls.endDateTime.setValue(endDate);
    
    if(startDate>=endDate){
      alert("Wrong date input");
      return;
    }
    //alert
    // alert(startDate);
    // alert(endDate);

    this.notify.blockUi();
    this.service.createSurvey(this.createForm.value)
      .subscribe((data) => {
        this.cfsresponse = data;
        if (this.cfsresponse.statusCode==='200') {
          //this.list.push(data.dynamicSurvey);
          this.notify.success("New Survey created.");

          this.service.getAllDynamicSurvey().subscribe((data) => {
            this.list = data;
            //this.notify.blockUi(false);
          },
            error => {
              this.notify.error("Unable to load channels.");
              //this.notify.blockUi(false);
            });

          FormHelper.clean(this.createForm);
          this.notify.blockUi(false);
        } else {
          this.notify.warning(this.cfsresponse.statusMessage);
          this.notify.blockUi(false);
        }
        
      },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create channel.");
          }
          this.notify.blockUi(false);
        });
  }

}
