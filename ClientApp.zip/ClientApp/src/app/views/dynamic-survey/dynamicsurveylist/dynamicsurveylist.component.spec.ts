import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicsurveylistComponent } from './dynamicsurveylist.component';

describe('DynamicsurveylistComponent', () => {
  let component: DynamicsurveylistComponent;
  let fixture: ComponentFixture<DynamicsurveylistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicsurveylistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicsurveylistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
