import { Component, OnInit, Output } from '@angular/core';
import { DynamicSurvey, ProgressStatus } from '../../../models/dynamic-survey';
import { RxFormBuilder } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { DynamicSurveyService } from '../../../services/dynamic-survey.service';
import { SurveyQuestion } from '../../../models/survey-question';
import { HttpEventType } from '@angular/common/http';
import { EventEmitter } from 'events';
import { CFSResponse } from '../../../models/cfsresponse';
import { CfsRouterService } from '../../../services/cfs-router.service';

@Component({
  selector: 'app-dynamicsurveyaudiofileupload',
  templateUrl: './dynamicsurveyaudiofileupload.component.html',
  styleUrls: ['./dynamicsurveyaudiofileupload.component.scss']
})
export class DynamicsurveyaudiofileuploadComponent implements OnInit {
  IsUpload=[];
  editField: string;
  //@Output() public uploadStatus: EventEmitter<ProgressStatus>;
  selectedexistingsimrequest: DynamicSurvey;
  list: SurveyQuestion[] = [];
  searchName: string = "";
  cfsresponse: CFSResponse;

  constructor(private route: CfsRouterService
    , private formBuilder: RxFormBuilder
    , private notify: NotifyService
    , private service: DynamicSurveyService) {
   // this.createForm = this.formBuilder.formGroup();
  }

  ngOnInit() {
    this.selectedexistingsimrequest = JSON.parse(localStorage.getItem('selecteddynamicsurveyassignaudio') || '{}');

    this.pp();
  }
pp():void{
  this.notify.blockUi();
    this.service.getDynamicSurveyQuestion(this.selectedexistingsimrequest.id).subscribe(res => {
    this.list = res;
    
      //this.existingMSISDNRequestModel=res.json();
      //console.log('Existing MSISDN File upload data:' + res.json());
      this.notify.blockUi(false);
    });
}

  searchedItems(): SurveyQuestion[] {
    
    const values = this.list.filter(x =>
      x.questionId.toLowerCase().includes(this.searchName.toLowerCase())      
    );
    
    return values;
  }


  public upload(event,item: SurveyQuestion,i) {
    if(item.audioFileType==='questionary'){
      if(item.optionNo===0){
        alert("You must put no of option for this file...");
        return;
      }
    }    
    
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];

      this.notify.blockUi();
      //this.uploadStatus.emit( {status: ProgressStatusEnum.START});
      this.service.uploadFile(file, item).subscribe(
        data => {
          if (data) {
            switch (data.type) {
              case HttpEventType.UploadProgress:
                //this.uploadStatus.emit( {status: ProgressStatusEnum.IN_PROGRESS, percentage: Math.round((data.loaded / data.total) * 100)});
                break;
              case HttpEventType.Response:
  //              this.inputFile.nativeElement.value = '';
               // this.uploadStatus.emit( {status: ProgressStatusEnum.COMPLETE});
                break;
            }
            
            this.notify.blockUi(false);            
          }
          
        },        
        error => {
          alert("File Uploaded Failure....");
    //      this.inputFile.nativeElement.value = '';
          //this.uploadStatus.emit( {status: ProgressStatusEnum.ERROR});
        },
        () => {
          alert("File uploaded success");
         // this.list[i].audioFileName=this.list[i].questionId;
         this.pp();
        }
      );
    
    
    
    }

    
  }

  public delete(item: SurveyQuestion,i) {
    this.service.deleteFile(item).subscribe(
      data => {
        switch (data.type) {
          case HttpEventType.DownloadProgress:
         // this.notify.blockUi(false);
            //this.downloadStatus.emit( {status: ProgressStatusEnum.IN_PROGRESS, percentage: Math.round((data.loaded / data.total) * 100)});
            break;
          case HttpEventType.Response:
            //this.downloadStatus.emit( {status: ProgressStatusEnum.COMPLETE});
            const downloadedFile = new Blob([data.body], { type: data.body.type });
            const a = document.createElement('a');
            a.setAttribute('style', 'display:none;');
            document.body.appendChild(a);
            a.download = item.questionId;
            a.href = URL.createObjectURL(downloadedFile);
            a.target = '_blank';
            //a.click();
            document.body.removeChild(a);
            //this.notify.blockUi(false);
            break;
            
        }
      },
      error => {
       // this.downloadStatus.emit( {status: ProgressStatusEnum.ERROR});
      },      
        () => {
          alert("File deleted success");
          
          this.list[i].audioFileName="";
        }
      
    );
  }

  public download(item: SurveyQuestion) {
    
    //this.downloadStatus.emit( {status: ProgressStatusEnum.START});
    //this.notify.blockUi();
    this.service.downloadFile(item).subscribe(
      data => {
        switch (data.type) {
          case HttpEventType.DownloadProgress:
         // this.notify.blockUi(false);
            //this.downloadStatus.emit( {status: ProgressStatusEnum.IN_PROGRESS, percentage: Math.round((data.loaded / data.total) * 100)});
            break;
          case HttpEventType.Response:
            //this.downloadStatus.emit( {status: ProgressStatusEnum.COMPLETE});
            const downloadedFile = new Blob([data.body], { type: data.body.type });
            const a = document.createElement('a');
            a.setAttribute('style', 'display:none;');
            document.body.appendChild(a);
            a.download = item.questionId;
            a.href = URL.createObjectURL(downloadedFile);
            a.target = '_blank';
            a.click();
            document.body.removeChild(a);
            //this.notify.blockUi(false);
            break;
            
        }
      },
      error => {
       // this.downloadStatus.emit( {status: ProgressStatusEnum.ERROR});
      }
      
    );
  }


  changeValue(id: number, property: string, event: any) {
    this.editField = event.target.textContent;
  }

  updateList(id: number, property: string, event: any) {
    const editField = event.target.textContent;
    this.list[id][property] = editField;
  }

  saveaudio() {
    // FormHelper.startValidating(this.createForm);
    // if (this.createForm.invalid) {
    //   return;
    // }

    this.notify.blockUi();
    this.service.createPhpfile(this.list)
      .subscribe((data) => {
        this.cfsresponse = data;
        if (this.cfsresponse.statusCode==='200') {
          // this.list.push(data.dynamicSurvey);
         this.notify.success(this.cfsresponse.statusMessage);
          // FormHelper.clean(this.createForm);
          this.notify.blockUi(false);
          this.route.viewDynamicSurveys();
        } else {
          this.notify.warning(this.cfsresponse.statusMessage);
          this.notify.blockUi(false);
        }
        
      },
        error => {
          // if (HttpHelper.isValidationError(error)) {
          //   FormHelper.mappValidationErrors(this.createForm, error)
          // } else {
          //   this.notify.error("Unable to create channel.");
          // }
          this.notify.blockUi(false);
        });
    }
}
