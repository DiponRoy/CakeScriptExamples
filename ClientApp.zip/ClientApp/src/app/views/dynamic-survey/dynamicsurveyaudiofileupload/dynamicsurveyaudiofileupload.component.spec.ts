import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicsurveyaudiofileuploadComponent } from './dynamicsurveyaudiofileupload.component';

describe('DynamicsurveyaudiofileuploadComponent', () => {
  let component: DynamicsurveyaudiofileuploadComponent;
  let fixture: ComponentFixture<DynamicsurveyaudiofileuploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicsurveyaudiofileuploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicsurveyaudiofileuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
