import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard, PermissionGuardService as PermissionGuard } from '../../services/auth-guard.service';
import { DynamicsurveylistComponent } from './dynamicsurveylist/dynamicsurveylist.component';
import { DynamicsurveymsisdnuploadComponent } from './dynamicsurveymsisdnupload/dynamicsurveymsisdnupload.component';
import { DynamicsurveyaudiofileuploadComponent } from './dynamicsurveyaudiofileupload/dynamicsurveyaudiofileupload.component';
import { PermissionEnum } from '../../core/enum';
import { DynamicsurveydetailviewComponent } from './dynamicsurveydetailview/dynamicsurveydetailview.component';

 


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Dynamic Survey'
    },
    children: [
      {
        path: '',
        redirectTo: 'dynamicsurveylist'
      }
      ,
      {
        path: 'dynamicsurveylist',
        component: DynamicsurveylistComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.DynamicSurveyList],
          title: 'Dynamic Survey List'
        }
      },
      {
        path: 'dynamicsurveymsisdnupload',
        component: DynamicsurveymsisdnuploadComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.DynamicSurveyList],
          title: 'Dynamic Survey MSISDN Upload'
        }
      },
      {
        path: 'dynamicsurveyaudiofileupload',
        component: DynamicsurveyaudiofileuploadComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.DynamicSurveyList],
          title: 'Dynamic Survey Audio file upload'
        }
      },
      {
        path: 'dynamicsurveydetailview',
        component: DynamicsurveydetailviewComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.DynamicSurveyList],
          title: 'Dynamic Survey View Detail'
        }
      },
          
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DynamicSurveyRoutingModule {}
