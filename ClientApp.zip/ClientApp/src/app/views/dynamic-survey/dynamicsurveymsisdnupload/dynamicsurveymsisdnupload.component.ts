import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RxFormBuilder, required, digit, propArray, endsWith, startsWith, maxLength, minLength, minNumber, unique, rule, choice } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { ReportUserService } from '../../../services/report-user.service';
import { DynamicSurvey } from '../../../models/dynamic-survey';
import * as XLSX from 'xlsx';
import { DynamicSurveyMsisdn, DynamicSurveyMsisdnUpload } from '../../../models/dynamic-survey-msisdn';
import { DynamicSurveyService } from '../../../services/dynamic-survey.service';
import { ExcelService } from '../../../utilities/excel.service';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';
import { CfsRouterService } from '../../../services/cfs-router.service';


export class MsisdnFile {
  Msisdn: string
}

export class BulkMsisdnModel {

  @choice({ maxLength: 1, message: "Duplicate msisdn or input." })
  duplicateMsisdns: string[];
  @required()
  @digit()
  @startsWith({ value:'0', message: "Msisdn should start with 0." })
  @minLength({ value: 11, message: "Minimum value should be 11."})
  @maxLength({ value: 11, message: "Maximum value should be 11."})
  msisdn: string;

  setFromModel(model: MsisdnFile, models: MsisdnFile[]) {
    this.msisdn = model.Msisdn;
    this.duplicateMsisdns = [];
    models.filter(x => x.Msisdn === model.Msisdn)
    .forEach(x => { 
      this.duplicateMsisdns.push(x.Msisdn); 
    });
  }
}

export class MsisdnBulkUploadModel {
  @required()
  file: File = null;

  @required()
  @digit()
  @minNumber({ value: 1, message: "Minimum value should be 1."})
  surveyId: number;

  @endsWith({ value:'.xlsx', message: "File format should be .xlsx" })
  sourceDetail: string = '';
}

@Component({
  selector: 'app-dynamicsurveymsisdnupload',
  templateUrl: './dynamicsurveymsisdnupload.component.html',
  styleUrls: ['./dynamicsurveymsisdnupload.component.scss']
})
export class DynamicsurveymsisdnuploadComponent implements OnInit {
  showOnlyErrorRows: boolean = false;
  surveyId = 0;
  surveyName = "";
  file: File;
  createForm: FormGroup;
  msisdnlist: FormGroup[];
    
  protected existingMSISDNRequestModel: Array<DynamicSurveyMsisdn>;
  
  constructor(private formBuilder: RxFormBuilder
    , private router: CfsRouterService
    , private notify: NotifyService
    , private excelService: ExcelService
    , private service: DynamicSurveyService) {

      const model = JSON.parse(localStorage.getItem('selecteddynamicsurveyassignmsisdn') || '{}');
      this.surveyId = model.id;
      this.surveyName = model.name;
  
      this.createForm = this.formBuilder.formGroup(new MsisdnBulkUploadModel());
      this.createForm.controls.surveyId.setValue(this.surveyId);
      this.msisdnlist = [];
  }

  searchedItems(): FormGroup[] {
    let formgroups = this.msisdnlist
    let list = this.showOnlyErrorRows ? formgroups.filter(x => x.invalid) : formgroups;
    return list;
  }

  setMsisdnListToForm(list: MsisdnFile[]) {
    this.msisdnlist = [];
    list.forEach( x => {     
      let model = new BulkMsisdnModel();
      model.setFromModel(x, list)
      let form = this.formBuilder.formGroup<BulkMsisdnModel>(model);
      this.msisdnlist.push(form);
      FormHelper.startValidating(form);       
    });
  }

  processFile(event) {
    this.setMsisdnListToForm([]);
    this.createForm.controls.file.setValue(null);
    this.createForm.controls.file.markAsDirty();
    this.createForm.controls.sourceDetail.setValue('');
    this.createForm.controls.sourceDetail.markAsDirty();

    if(event.target.files.lenght < 1){
      return;
    }
    var file: File = event.target.files[0];
    this.file = event.target.files[0];
    this.createForm.controls.file.setValue(this.file);
    this.createForm.controls.sourceDetail.setValue('Ui:File:' + this.file.name);

    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      const dataList = this.excelService.readFileAs<MsisdnFile>(fileReader);
      this.setMsisdnListToForm(dataList);
    };
    fileReader.onloadstart = (e) => {
      this.notify.blockUi();
    };
    fileReader.onloadend = (e) => {
      this.notify.blockUi(false);
    };
    fileReader.onerror = (e) => {
      this.notify.blockUi(false);
      this.notify.error("Unable to load file.");
    };
    fileReader.readAsArrayBuffer(this.file);
  }

  upload() {
    FormHelper.startValidating(this.createForm);
    let formgroups = this.msisdnlist;
    formgroups.forEach(form => {
      FormHelper.startValidating(form);       
    });
    let hasErrorRows = formgroups.filter(x => x.invalid).length > 0;
    if (this.createForm.invalid || hasErrorRows) {  
      this.notify.warning('Validation error.');
      return;
    }
    if (formgroups.length < 1) {     
      this.notify.warning('No msisdn found inside the uploaded file.');
      return;
    }

    this.notify.blockUi();
    var bulkUpload: DynamicSurveyMsisdnUpload = {
      surveyId: this.createForm.controls.surveyId.value,
      msisdns: this.msisdnlist.map(x => x.value)
    };
    this.service.postmsisdnforsurvey(bulkUpload).subscribe(data => {
      this.setMsisdnListToForm([]);
      this.notify.success('Msisdn list uploaded.');
      this.notify.info("Redirecting to survey list page.");
      setTimeout(() => {
        this.router.viewDynamicSurveys();
      }, 300);
    }, error => {
      this.notify.error('Error to upload file.');
      this.notify.blockUi(false);  
    })

  }

  // deleteAllMsisdn() {
  //   this.notify.blockUi();
  //   this.service.deleteSurveyMSISDNBySurveyId(this.surveyId)
  //   .subscribe((data) => {
  //     this.notify.success("MSISDN List of this survey is deleted");
  //     this.notify.blockUi(false);
  //   },
  //   error => {          
  //     this.notify.blockUi(false);
  //   });
  // }

  downloadFileSample() {
    let list = [];
    let model = new MsisdnFile();
    model.Msisdn = "017"
    list.push(model);
    this.excelService.exportAsExcelFile(list, 'Msisdns'); 
  }

  ngOnInit() {

  }
}


