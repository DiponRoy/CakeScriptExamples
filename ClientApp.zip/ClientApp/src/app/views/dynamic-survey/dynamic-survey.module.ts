import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// Collapse Component
import { CollapseModule } from 'ngx-bootstrap/collapse';
//import { CollapsesComponent } from './collapses.component';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';

import { ModalModule, PopoverModule } from 'ngx-bootstrap';
import { DynamicSurveyRoutingModule } from './dynamic-survey-routing.module';
import { DynamicsurveylistComponent } from './dynamicsurveylist/dynamicsurveylist.component';
import { DynamicsurveymsisdnuploadComponent } from './dynamicsurveymsisdnupload/dynamicsurveymsisdnupload.component';
import { DynamicsurveyaudiofileuploadComponent } from './dynamicsurveyaudiofileupload/dynamicsurveyaudiofileupload.component';
import { DynamicsurveydetailviewComponent } from './dynamicsurveydetailview/dynamicsurveydetailview.component';

 



// Angular
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    CollapseModule.forRoot(),
    AutocompleteLibModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),

    ModalModule.forRoot(),
    PopoverModule.forRoot(),

    DynamicSurveyRoutingModule,
  ],
  declarations: [    
    
  DynamicsurveylistComponent, DynamicsurveymsisdnuploadComponent, DynamicsurveyaudiofileuploadComponent,DynamicsurveydetailviewComponent
    ],
  entryComponents: [
    
  ], 

  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class DynamicSurveyModule { }
