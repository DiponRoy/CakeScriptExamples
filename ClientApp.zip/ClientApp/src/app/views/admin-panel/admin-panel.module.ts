import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';

import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { AdminPanelRoutingModule } from './admin-panel-routing.module';
import { RoleComponent } from './role.component';
import { PageComponent } from './page.component';
import { UserComponent } from './user.component';
import { UserRoleMappComponent } from './user-role-mapp.component';
import { RolePageMappComponent } from './role-page-mapp.component';

// Angular
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    CollapseModule.forRoot(),
    AutocompleteLibModule,
    BsDatepickerModule.forRoot(),

    AdminPanelRoutingModule,
  ],
  declarations: [
    RoleComponent,
    PageComponent,
    UserComponent,
    UserRoleMappComponent,
    RolePageMappComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AdminPanelModule { }
