import { Component, OnInit, EventEmitter } from '@angular/core';
import { AdminPanelService, AdminPanelUser, AdminPanelUserUpdate } from '../../../services/admin-panel.service';
import { ReportUserChannel } from '../../../models/report-user.model';
import { NotifyService } from '../../../utilities/notify.service';
import { RxFormBuilder, required, prop, email, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';


export class UserModel implements AdminPanelUserUpdate {
  @required()
  @maxLength({ value: 50 })
  oldId: string;
  @required()
  @maxLength({ value: 50 })
  id: string = "";
  @email()
  @required()
  @maxLength({ value: 100 })
  email: string = "";
  @required()
  @maxLength({ value: 100 })
  name: string = "";
}

@Component({
  selector: 'app-admin-panel-user-update',
  templateUrl: './user-update.component.html'
})
export class UserUpdateComponent {
  updateModel: UserModel = new UserModel();
  updateForm: FormGroup;
  afterUpdate: EventEmitter<AdminPanelUser> = new EventEmitter();


  constructor(private formBuilder: RxFormBuilder, private service: AdminPanelService, private notify: NotifyService) {
    this.updateForm = this.formBuilder.formGroup(this.updateModel);
  }

  update() {
    FormHelper.startValidating(this.updateForm);
    if (this.updateForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.updateUser(this.updateForm.value)
      .subscribe((data) => {
        this.afterUpdate.emit(data);
        this.notify.success("User updated.");
        this.notify.blockUi(false);
      },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.updateForm, error)
          } else {
            this.notify.error("Unable to update user.");
          }
          this.notify.blockUi(false);
        });
  }


  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  isVisible: boolean = true;
  public display(flag: boolean = true) {
    this.isVisible = flag;
  }

  public set(model: AdminPanelUserUpdate) {
    this.updateForm.controls.oldId.setValue(model.id);
    this.updateForm.controls.id.setValue(model.id);
    this.updateForm.controls.email.setValue(model.email);
    this.updateForm.controls.name.setValue(model.name);
  }
}