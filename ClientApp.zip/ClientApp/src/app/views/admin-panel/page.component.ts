import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../utilities/notify.service';
import { AdminPanelService, AdminPanelPage } from '../../services/admin-panel.service';

@Component({
  selector: 'app-admin-panel-page',
  templateUrl: './page.component.html'
})
export class PageComponent implements OnInit {
  searchName: string = "";
  list: AdminPanelPage[] = [];

  constructor(private service: AdminPanelService, private notify: NotifyService) { 
  }

  searchedRoles(): AdminPanelPage[]{
    const values = this.list.filter(x => 
        x.displayName.toLowerCase().includes(this.searchName.toLowerCase()) 
    );
    return values;
  }

  ngOnInit() {
    this.notify.blockUi();
    this.service.pages().subscribe((data) => {
      this.list = data;
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Unable to load page list.");
      this.notify.blockUi(false);
    });
  }
}