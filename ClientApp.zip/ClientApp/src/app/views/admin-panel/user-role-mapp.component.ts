import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ConfirmDialogService } from '../../elements/confirm-dialog/confirm-dialog.service';
import { forkJoin } from 'rxjs';
import { AutocompleteComponent } from 'angular-ng-autocomplete';
import { required, prop, RxFormBuilder, digit } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { NotifyService } from '../../utilities/notify.service';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { AdminPanelService, AdminPanelUser, AdminPanelRole, AdminPanelUserVsRole } from '../../services/admin-panel.service';


export class UserVsRoleModel implements AdminPanelUserVsRole {
  @prop()
  id: number;
  @required()
  userId: string;
  @digit({message: 'Unknown role.'})
  @required()
  roleId: number;
}

export class UserVsRoleViewModel {
  id: number;
  userId: string = "";
  roleName: string = "";
}


@Component({
  selector: 'app-admin-panel-user-role-mapp',
  templateUrl: './user-role-mapp.component.html'
})
export class UserRoleMappComponent implements OnInit {

  users: AdminPanelUser[] = [];
  roles: AdminPanelRole[] = [];
  @ViewChild('autoUser', { static: false }) autoUser: AutocompleteComponent;
  @ViewChild('autoRole', { static: false }) autoRole: AutocompleteComponent;
  createModel: AdminPanelUserVsRole = new UserVsRoleModel();
  createForm: FormGroup;

  searchModel: UserVsRoleViewModel = new UserVsRoleViewModel();
  userRoleMapps: AdminPanelUserVsRole[] = [];


  constructor(private formBuilder: RxFormBuilder, private service: AdminPanelService, private notify: NotifyService) {
      this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  selectUser(item: AdminPanelUser) {
    this.createForm.controls.userId.setValue(item.id);
    this.createForm.controls.userId.markAsDirty();
  }
  selectUserChange(value: string) {
    this.createForm.controls.userId.setValue(value);
    this.createForm.controls.userId.markAsDirty();
  }

  selectRole(item: AdminPanelRole) {
    this.createForm.controls.roleId.setValue(item.id);
    this.createForm.controls.roleId.markAsDirty();
  }
  selectRoleChange(value: string) {
    this.createForm.controls.roleId.setValue(-1);
    this.createForm.controls.roleId.markAsDirty();
  }

  searchedUserVsRoles(): UserVsRoleViewModel[] {
    const values = this.mapp(this.userRoleMapps).filter(x =>
      x.userId.toLowerCase().includes(this.searchModel.userId.toLowerCase())
      && x.roleName.toLowerCase().includes(this.searchModel.roleName.toLowerCase())
    );
    return values;
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createUserRoleMapp(this.createModel)
    .subscribe((data) => {
      this.userRoleMapps.push(data);
      FormHelper.cleanAutocomplete(this.autoUser);
      FormHelper.cleanAutocomplete(this.autoRole);
      FormHelper.clean(this.createForm);

      this.notify.success("Role assigned to user.");
      this.notify.blockUi(false);
    },
    error => {
      if (HttpHelper.isValidationError(error)) {
        FormHelper.mappValidationErrors(this.createForm, error)
      } else {
        this.notify.error("Error to assign user to the  role.");
      }
      this.notify.blockUi(false);
    });
  }

  remove(item: UserVsRoleViewModel) {
    const index = this.userRoleMapps.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want remove user:'${item.userId}' form role:'${item.roleName}'?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteUserRoleMapp(item.id).subscribe((data)=>{
            this.userRoleMapps.splice(index, 1);
            this.notify.success("User removed from the role.");
            this.notify.blockUi(false);
          },
          error => {
            this.notify.error("Unable to remove user from the role.");
            this.notify.blockUi(false);
          });
        }
      });
  }

  mapp(items: AdminPanelUserVsRole[]): UserVsRoleViewModel[] {
    const mapps: UserVsRoleViewModel[] = [];
    items.forEach((m) => {
      const mapp = new UserVsRoleViewModel();
      mapp.id = m.id;
      mapp.userId = m.userId;
      mapp.roleName = this.roles.filter(x => x.id === m.roleId)[0].name
      mapps.push(mapp);
    });
    return mapps;
  }


  ngOnInit() {
    this.notify.blockUi();
    forkJoin([
      this.service.users(),
      this.service.roles(),
      this.service.userRoleMapps()
    ]).subscribe((res) => {
      this.users = res[0];
      this.roles = res[1];
      this.userRoleMapps = res[2];
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load page.");
      this.notify.blockUi(false);
    });
  }

  /*create form*/
  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }
}
