import { Component, OnInit } from '@angular/core';
import { NotifyService } from '../../utilities/notify.service';
import { RxFormBuilder, required, prop, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { AdminPanelService, AdminPanelRole } from '../../services/admin-panel.service';


export class AdminPanelRoleModel implements AdminPanelRole {
  @prop()
  id: number
  @required()
  @maxLength({ value: 50 })
  name: string = "";
  @prop()
  @maxLength({ value: 250 })
  details: string = "";
}

@Component({
  selector: 'app-admin-panel-role',
  templateUrl: './role.component.html'
})
export class RoleComponent implements OnInit {
  createModel: AdminPanelRoleModel = new AdminPanelRoleModel();
  createForm: FormGroup;

  searchName: string = "";
  list: AdminPanelRole[] = [];

  constructor(private formBuilder: RxFormBuilder, private service: AdminPanelService, private notify: NotifyService) {
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  searchedItems(): AdminPanelRole[] {
    const values = this.list.filter(x =>
      x.name.toLowerCase().includes(this.searchName.toLowerCase())
    );
    return values;
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createRole(this.createForm.value)
      .subscribe((data) => {
        this.list.push(data);
        this.notify.success("Role created.");
        FormHelper.clean(this.createForm);
        this.notify.blockUi(false);
      },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create role.");
          }
          this.notify.blockUi(false);
        });
  }

  remove(item: AdminPanelRole) {
    const index = this.list.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want to remove this role?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteRole(item.id)
          .subscribe((data) => {
            this.notify.success("Role deleted.");
            this.list.splice(index, 1);

            this.notify.blockUi(false);
          },
          error => {
            if (HttpHelper.isValidationError(error)) {
              const msgs = FormHelper.fieldValidationErrors(error, 'id')
              const msg = msgs.length ? msgs[0] : "Unable to delete."
              this.notify.warning(msg);
            } else {
              this.notify.error("Unable to delete role.");
            }
            this.notify.blockUi(false);
          });
        }
      });
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  ngOnInit() {
    this.notify.blockUi();
    this.service.roles().subscribe((data) => {
      this.list = data;
      this.notify.blockUi(false);
    },
      error => {
        this.notify.error("Unable to load roles.");
        this.notify.blockUi(false);
      });
  }
}