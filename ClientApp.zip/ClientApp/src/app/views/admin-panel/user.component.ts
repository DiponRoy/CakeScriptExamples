import { Component, OnInit } from '@angular/core';
import { AdminPanelService, AdminPanelUser } from '../../services/admin-panel.service';
import { ReportUserChannel } from '../../models/report-user.model';
import { NotifyService } from '../../utilities/notify.service';
import { RxFormBuilder, required, prop, email, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';


export class UserModel implements AdminPanelUser {
  @required()
  @maxLength({ value: 100 })
  name: string = "";
  @email()
  @required()
  @maxLength({ value: 100 })
  email: string = "";
  @required()
  @maxLength({ value: 50 })
  id: string = "";
}

@Component({
  selector: 'app-admin-panel-user',
  templateUrl: './user.component.html'
})
export class UserComponent implements OnInit {
  createModel: UserModel = new UserModel();
  createForm: FormGroup;

  searchDomainId: string = "";
  list: UserModel[] = [];

  constructor(private formBuilder: RxFormBuilder, private service: AdminPanelService, private notify: NotifyService) {
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  searchedItems(): UserModel[] {
    const values = this.list.filter(x =>
      x.id.toLowerCase().includes(this.searchDomainId.toLowerCase())
    );
    return values;
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createUser(this.createForm.value)
      .subscribe((data) => {
        this.list.push(data);
        this.notify.success("User created.");
        FormHelper.clean(this.createForm);
        this.notify.blockUi(false);
      },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create user.");
          }
          this.notify.blockUi(false);
        });
  }

  remove(item: ReportUserChannel) {
    const index = this.list.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want to remove this user?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteUser(item.id)
          .subscribe((data) => {
            this.notify.success("User deleted.");
            this.list.splice(index, 1);

            this.notify.blockUi(false);
          },
          error => {
            if (HttpHelper.isValidationError(error)) {
              const msgs = FormHelper.fieldValidationErrors(error, 'id')
              const msg = msgs.length ? msgs[0] : "Unable to delete."
              this.notify.warning(msg);
            } else {
              this.notify.error("Unable to delete user.");
            }
            this.notify.blockUi(false);
          });
        }
      });
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  ngOnInit() {
    this.notify.blockUi();
    this.service.users().subscribe((data) => {
      this.list = data;
      this.notify.blockUi(false);
    },
      error => {
        this.notify.error("Unable to load user.");
        this.notify.blockUi(false);
      });
  }
}