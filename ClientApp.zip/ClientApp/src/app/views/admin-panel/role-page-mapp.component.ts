/*
Link:
check box usages: 
http://marcusresell.com/2018/07/18/dynamic-checkbox-angular/
https://netbasal.com/handling-multiple-checkboxes-in-angular-forms-57eb8e846d21
https://stackoverflow.com/questions/40927167/angular-reactiveforms-producing-an-array-of-checkbox-values
https://stackoverflow.com/questions/44431613/cannot-find-control-with-name-formcontrolname-in-angular-2-or-4
*/

import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../utilities/notify.service';
import { AutocompleteComponent } from 'angular-ng-autocomplete';
import { RxFormBuilder, prop, required, maxLength, digit, propArray } from '@rxweb/reactive-form-validators';
import { FormGroup, FormArray } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { forkJoin } from 'rxjs';
import { AdminPanelService, AdminPanelRole, AdminPanelUserVsRole, AdminPanelRoleVsPage, AdminPanelPage } from '../../services/admin-panel.service';


export class PageModel implements AdminPanelPage {
  @prop()
  id: number;
  @prop()
  displayName: string;
  @prop()
  details: string;
  @prop()
  isSelected: boolean = false;


  public mapp(page: AdminPanelPage){
    this.id = page.id;
    this.displayName = page.displayName;
    this.details = page.details;
  }
}

export class AdminPanelRoleVsPageModel implements AdminPanelRoleVsPage {
  @prop()
  id: number;
  @prop()
  pageId: number;
  @digit({message: 'Unknown role.'})
  @required()  
  roleId: number;
}

@Component({
  selector: 'app-admin-panel-role-page-mapp',
  templateUrl: './role-page-mapp.component.html'
})
export class RolePageMappComponent implements OnInit {
  @ViewChild('autoRole', {static: false}) auto: AutocompleteComponent;
  roles: AdminPanelRole[] = [];
  selectAllPage: boolean = false;
  pages: PageModel[] = [];

  createModel: AdminPanelRoleVsPageModel = new AdminPanelRoleVsPageModel();
  createForm: FormGroup;

  constructor(private formBuilder: RxFormBuilder, private service: AdminPanelService, private spinner: NgxSpinnerService, private notify: NotifyService) { 
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  selectRole(item: AdminPanelRole) {
    this.createForm.controls.roleId.setValue(item.id);
    this.createForm.controls.roleId.markAsDirty();
    this.uncheckPages();
    this.getPages(item.id);
  }
  roleChange(value: string) {
    this.createForm.controls.roleId.setValue(-1);
    this.createForm.controls.roleId.markAsDirty();
  }

  uncheckPages() {
    this.pages.forEach(x => {
      x.isSelected = false;       
    });
    this.selectAllPage = false;
  }
  onCheckChange(event) {
    var value = event.target.checked
    this.pages.forEach(x => {
      x.isSelected = value;       
    });
  }

  getPages(roleId: number) {
    this.notify.blockUi();
    this.service.rolePageMapps(roleId).subscribe((data) => {
      var list = this.pages.filter(x => data.some(d => x.id === d.pageId ));
      list.forEach(x => { x.isSelected = true; });
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Unable to get pages of selected role.");
      this.notify.blockUi(false);
    });
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    const pageIds = this.pages
      .filter(p => p.isSelected === true)
      .map(x => x.id);
    this.service.upsertRolePageMapps({
      roleId: this.createForm.controls.roleId.value,
      pageIds: pageIds
    })
    .subscribe((data) => {
      FormHelper.cleanAutocomplete(this.auto);
      FormHelper.clean(this.createForm); 
      this.uncheckPages(); 

      this.notify.success("Pages added to the role.");
      this.notify.blockUi(false);
    },
    error => {
      if (HttpHelper.isValidationError(error)) {
        FormHelper.mappValidationErrors(this.createForm, error)
      } else {
        this.notify.error("Unable to add pages to the role.");
      }
      this.notify.blockUi(false);
    });
  }

  pageModels(list: AdminPanelPage[]): PageModel[]{
    var mapp: PageModel[] = [];
    list.forEach( x => {     
      let model = new PageModel();
      model.mapp(x)
      mapp.push(model);
    });
    return mapp;
  }

  ngOnInit() {
    this.notify.blockUi();
    forkJoin([this.service.roles(), this.service.pages()]).subscribe(
      (res) => {
      this.roles = res[0];
      this.pages = this.pageModels(res[1]);
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load page.");
      this.notify.blockUi(false);
    });
  }
}