import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard, PermissionGuardService as PermissionGuard } from '../../services/auth-guard.service';

import { UserComponent } from './user.component';
import { RoleComponent } from './role.component';
import { PageComponent } from './page.component';
import { UserRoleMappComponent } from './user-role-mapp.component';
import { RolePageMappComponent } from './role-page-mapp.component';
import { PermissionEnum } from '../../core/enum';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'User List'
    },
    children: [
      {
        path: '',
        redirectTo: 'users'
      },   
      {
        path: 'users',
        component: UserComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.AdminUserList],
          title: 'User List'
        }
      },  
      {
        path: 'roles',
        component: RoleComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.AdminUserRole],
          title: 'Role List'
        }
      },
      {
        path: 'pages',
        component: PageComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.AdminUserPage],
          title: 'Page List'
        }
      },
      {
        path: 'user-vs-role',
        component: UserRoleMappComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.AdminUserVsRole],
          title: 'User Vs Role'
        }
      },
      {
        path: 'role-vs-page',
        component: RolePageMappComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.AdminUserRoleVsPage],
          title: 'Role Vs Page'
        }
      }        
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminPanelRoutingModule {}
