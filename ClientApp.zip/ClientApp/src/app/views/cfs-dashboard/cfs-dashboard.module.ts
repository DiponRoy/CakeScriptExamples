import { NgModule } from '@angular/core';
import { CfsDashboardComponent } from './cfs-dashboard.component';
import { CfsDashboardRoutingModule } from './cfs-dashboard-routing.module';

@NgModule({
  imports: [
    CfsDashboardRoutingModule,
  ],
  declarations: [ CfsDashboardComponent ]
})
export class CfsDashboardModule { }
