import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: 'cfs-dashboard.component.html'
})
export class CfsDashboardComponent {

  constructor() { }

}