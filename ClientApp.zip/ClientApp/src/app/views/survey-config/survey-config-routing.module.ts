import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard, PermissionGuardService as PermissionGuard } from '../../services/auth-guard.service';

import { NonIvrConfigsComponent } from './non-ivr/non-ivr-configs.component';
import { IvrConfigsComponent } from './ivr/ivr-configs.component';
import { PermissionEnum } from '../../core/enum';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Configs'
    },
    children: [
      {
        path: '',
        redirectTo: 'non-ivr'
      },
      {
        path: 'non-ivr',
        component: NonIvrConfigsComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.SurveyConfigNonIvr],
          title: 'Non Ivr Configs'
        }
      },
      {
        path: 'ivr',
        component: IvrConfigsComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.SurveyConfigIvr],
          title: 'Ivr Configs'
        }
      },  
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SurveyConfigRoutingModule {}
