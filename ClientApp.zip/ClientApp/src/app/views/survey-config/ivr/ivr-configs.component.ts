import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-ivr-configs',
  templateUrl: './ivr-configs.component.html'
})
export class IvrConfigsComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService) { 
  }


  ngOnInit() {
  }
}