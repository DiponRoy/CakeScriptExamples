import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../../../utilities/notify.service';
import { required, minNumber, RxFormBuilder, digit } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../../utilities/form.helper';
import { IvrSurveyConfigService, Ipcc } from '../../../../services/ivr-survey-config.service';


export class IpccConfigModel implements Ipcc {
  @required()
  @digit()
  @minNumber({ value: 0, message:"Minimum value is 0" })
  resurveyDuration?: number;
}

@Component({
  selector: 'app-ipcc-configs',
  templateUrl: './ipcc-configs.component.html'
})
export class IpccConfigsComponent implements OnInit {

  upsertModel = new IpccConfigModel();
  upsertForm: FormGroup;

  constructor(private formBuilder: RxFormBuilder, private notify: NotifyService, private service: IvrSurveyConfigService) {
    this.upsertForm = this.formBuilder.formGroup(this.upsertModel);
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';

  collapsed(event: any): void {
    // console.log(event);
  }

  expanded(event: any): void {
    this.load();
  }

  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  load(): void {
    this.notify.blockUi();
    this.service.Ipcc().subscribe(
      (data) => {
        this.upsertForm.controls.resurveyDuration.setValue(data.resurveyDuration);
        this.notify.blockUi(false);
      },
      (error) => {
        this.notify.error("Error to load configs.");
        this.notify.blockUi(false);
      }
    );
  }

  save(): void {
    FormHelper.startValidating(this.upsertForm);
    if(this.upsertForm.invalid) {
      return; 
    }

    this.notify.blockUi();
    this.service.createIpcc(this.upsertForm.value).subscribe(
      (data) => {
        this.notify.success("Config saved.");
        this.notify.blockUi(false);
      },
      error => {
        if(HttpHelper.isValidationError(error)){
          FormHelper.mappValidationErrors(this.upsertForm, error)
        } else {
          this.notify.error("Unable to save config.");
        }
        this.notify.blockUi(false);
      });
  }

  ngOnInit() {
  }


}