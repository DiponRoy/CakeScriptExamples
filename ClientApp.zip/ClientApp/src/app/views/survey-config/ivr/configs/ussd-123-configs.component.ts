import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../../../utilities/notify.service';
import { required, minNumber, RxFormBuilder, digit } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../../utilities/form.helper';
import { IvrSurveyConfigService, Ussd121 } from '../../../../services/ivr-survey-config.service';


export class Ussd121ConfigModel implements Ussd121 {
  @required()
  @digit()
  @minNumber({ value: 0, message:"Minimum value is 0" })
  resurveyDuration?: number;
  @required()
  @digit()
  @minNumber({ value: 0, message:"Minimum value is 0" })
  dialPerDay?: number;
  @required()
  @digit()
  @minNumber({ value: 0, message:"Minimum value is 0" })
  maxRightAnswer?: number;
}

@Component({
  selector: 'app-ussd-123-configs',
  templateUrl: './ussd-123-configs.component.html'
})
export class Ussd123ConfigsComponent implements OnInit {

  upsertModel = new Ussd121ConfigModel();
  upsertForm: FormGroup;

  constructor(private formBuilder: RxFormBuilder, private notify: NotifyService, private service: IvrSurveyConfigService) {
    this.upsertForm = this.formBuilder.formGroup(this.upsertModel);
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';

  collapsed(event: any): void {
    // console.log(event);
  }

  expanded(event: any): void {
    this.load();
  }

  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  load(): void {
    this.notify.blockUi();
    this.service.ussd123().subscribe(
      (data) => {
        this.upsertForm.controls.resurveyDuration.setValue(data.resurveyDuration);
        this.upsertForm.controls.dialPerDay.setValue(data.dialPerDay);
        this.upsertForm.controls.maxRightAnswer.setValue(data.maxRightAnswer);
        this.notify.blockUi(false);
      },
      (error) => {
        this.notify.error("Error to load configs.");
        this.notify.blockUi(false);
      }
    );
  }

  save(): void {
    FormHelper.startValidating(this.upsertForm);
    if(this.upsertForm.invalid) {
      return; 
    }

    this.notify.blockUi();
    this.service.createUssd123(this.upsertForm.value).subscribe(
      (data) => {
        this.notify.success("Config saved.");
        this.notify.blockUi(false);
      },
      error => {
        if(HttpHelper.isValidationError(error)){
          FormHelper.mappValidationErrors(this.upsertForm, error)
        } else {
          this.notify.error("Unable to save config.");
        }
        this.notify.blockUi(false);
      });
  }

  ngOnInit() {
  }


}