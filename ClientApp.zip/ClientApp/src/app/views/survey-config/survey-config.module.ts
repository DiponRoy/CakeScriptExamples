import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// Collapse Component
import { CollapseModule } from 'ngx-bootstrap/collapse';
//import { CollapsesComponent } from './collapses.component';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { SurveyConfigRoutingModule } from './survey-config-routing.module';
import { NonIvrConfigsComponent } from './non-ivr/non-ivr-configs.component';
import { AllDigitalChannelConfigsComponent } from './non-ivr/configs/all-digital-channel-configs.component';

import { IvrConfigsComponent } from './ivr/ivr-configs.component';
import { Ivr123ConfigsComponent } from './ivr/configs/ivr-123-configs.component';
import { Ussd123ConfigsComponent } from './ivr/configs/ussd-123-configs.component';
import { MyGpSilentUserConfigsComponent } from './ivr/configs/my-gp-silent-user-configs.component';
import { IpccConfigsComponent } from './ivr/configs/ipcc-configs.component';
import { GpcConfigsComponent } from './ivr/configs/gpc-configs.component';
import { NetMeasurConfigsComponent } from './ivr/configs/net-measur-configs.component';
import { FeedbackAndIvrConfigsComponent } from './ivr/configs/feedback-and-ivr-configs.component';


// Angular

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    CollapseModule.forRoot(),
    AutocompleteLibModule,
    BsDatepickerModule.forRoot(),


    SurveyConfigRoutingModule,
  ],
  declarations: [
    NonIvrConfigsComponent,
    AllDigitalChannelConfigsComponent,
    FeedbackAndIvrConfigsComponent,
    
    Ivr123ConfigsComponent,
    Ussd123ConfigsComponent,
    MyGpSilentUserConfigsComponent,
    IpccConfigsComponent,
    GpcConfigsComponent,
    NetMeasurConfigsComponent,
    IvrConfigsComponent,
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class SurveyConfigModule { }
