import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NonIvrSurveyConfigService, AllDigitalChannelConfig } from '../../../../services/non-ivr-survey-config.service';
import { NotifyService } from '../../../../utilities/notify.service';
import { required, minNumber, RxFormBuilder, digit } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../../utilities/form.helper';


export class AllDigitalChannelConfigModel implements AllDigitalChannelConfig {
  @required()
  @digit()
  @minNumber({ value: 0, message:"Minimum value is 0" })
  resurveyDuration: number = 0;
}

@Component({
  selector: 'app-all-digital-channel-configs',
  templateUrl: './all-digital-channel-configs.component.html'
})
export class AllDigitalChannelConfigsComponent implements OnInit {

  upsertModel = new AllDigitalChannelConfigModel();
  upsertForm: FormGroup;

  constructor(private formBuilder: RxFormBuilder, private notify: NotifyService, private service: NonIvrSurveyConfigService) {
    this.upsertForm = this.formBuilder.formGroup(this.upsertModel);
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';

  collapsed(event: any): void {
    // console.log(event);
  }

  expanded(event: any): void {
    this.load();
  }

  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  load(): void {
    this.notify.blockUi();
    this.service.allDigitalChannelConfig().subscribe(
      (data) => {
        this.upsertForm.controls.resurveyDuration.setValue(data.resurveyDuration);
        this.notify.blockUi(false);
      },
      (error) => {
        this.notify.error("Error to load configs.");
        this.notify.blockUi(false);
      }
    );
  }

  save(): void {
    FormHelper.startValidating(this.upsertForm);
    if(this.upsertForm.invalid) {
      return; 
    }

    this.notify.blockUi();
    this.service.createAllDigitalChannelConfig(this.upsertForm.value).subscribe(
      (data) => {
        this.notify.success("Config saved.");
        this.notify.blockUi(false);
      },
      error => {
        if(HttpHelper.isValidationError(error)){
          FormHelper.mappValidationErrors(this.upsertForm, error)
        } else {
          this.notify.error("Unable to save config.");
        }
        this.notify.blockUi(false);
      });
  }

  ngOnInit() {
  }


}