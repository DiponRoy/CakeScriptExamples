import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-non-ivr-configs',
  templateUrl: './non-ivr-configs.component.html'
})
export class NonIvrConfigsComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService) { 
  }

  ngOnInit() {
  }
}