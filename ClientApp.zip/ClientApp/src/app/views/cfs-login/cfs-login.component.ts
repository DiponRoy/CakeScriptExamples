import { Component, OnInit, ViewChild } from '@angular/core';
import { NotifyService } from '../../utilities/notify.service';
import { AccountService, TokenRequest } from '../../services/account.service';
import { FormGroup, Validators, FormBuilder, NgForm, FormGroupDirective, AbstractControl } from '@angular/forms';
import { RxFormBuilder, RxwebValidators, FormGroupExtension, required, error, RxFormGroup } from '@rxweb/reactive-form-validators';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { CfsRouterService } from '../../services/cfs-router.service';
import { LocalStorageService } from '../../services/local-storage.service';


export class LoginModel implements TokenRequest {
  @required()
  userName: string = "";
  @required()
  password: string = "";
}

@Component({
  selector: 'app-dashboard',
  templateUrl: 'cfs-login.component.html'
})
export class CfsLoginComponent implements OnInit {

  loginModel: LoginModel = new LoginModel();
  loginForm: FormGroup;

  constructor(private formBuilder: RxFormBuilder, private storage: LocalStorageService, private service: AccountService, private router: CfsRouterService, private notify: NotifyService){
    this.loginForm = this.formBuilder.formGroup(this.loginModel);
  }

  login(){
    FormHelper.startValidating(this.loginForm);
    if(this.loginForm.invalid) {
      return; 
    }

    this.notify.blockUi();
    this.service.token(this.loginForm.value).subscribe(
      data => {
        this.storage.setToken(data.token);
        this.notify.blockUi(false);
        this.notify.info("Creating session and redirecting to your dashboard.");
        this.setCurrentUserAndGotoDashboard();
      },
      error => {
        if(HttpHelper.isValidationError(error)){
          FormHelper.mappValidationErrors(this.loginForm, error)
        } else {
          this.notify.error("Unable to login.");
        }
        this.notify.blockUi(false);
      });
  }

  setCurrentUserAndGotoDashboard(){
    this.notify.blockUi();
    this.service.currentUser().subscribe(
      data => {
        this.storage.setCurrentUser(data);
        this.notify.blockUi(false);
        // setTimeout(() => {
        //   this.router.dashboard();     
        // }, 300);
        this.setCurrentUserPermission();
      },
      error => {
        if(HttpHelper.isValidationError(error)){
          FormHelper.mappValidationErrors(this.loginForm, error)
        } else {
          this.notify.error("Unable to get current user.");
        }
        this.notify.blockUi(false);
      });
  }

  setCurrentUserPermission(){
    this.notify.blockUi();
    this.service.permissions().subscribe(
      data => {
        this.storage.setPermissions(data.map(x => x.id));
        this.notify.blockUi(false);
        setTimeout(() => {
          this.router.dashboard();     
        }, 300);
      },
      error => {
        if(HttpHelper.isValidationError(error)){
          FormHelper.mappValidationErrors(this.loginForm, error)
        } else {
          this.notify.error("Unable to get current user permissions.");
        }
        this.notify.blockUi(false);
      });
  }

  reset(){
    FormHelper.clean(this.loginForm);
  }

  ngOnInit() {  
  }
}
