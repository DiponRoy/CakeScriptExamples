import { Component } from '@angular/core';

@Component({
  templateUrl: '601.component.html'
})
export class P601Component {

  constructor() { }

}
