import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

import { ReportRole, UserVsRoleViewModel, ReportUserRole, ReportUser } from '../../models/report-user.model';
import { ReportUserService } from '../../services/report-user.service';
import { ConfirmDialogService } from '../../elements/confirm-dialog/confirm-dialog.service';
import { forkJoin } from 'rxjs';
import { AutocompleteComponent } from 'angular-ng-autocomplete';
import { required, prop, RxFormBuilder, digit } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { NotifyService } from '../../utilities/notify.service';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';


export class UserVsRoleModel implements ReportUserRole {
  @prop()
  id: number;
  @required()
  userDomainId: string;
  @digit({message: 'Unknown role.'})
  @required()
  roleId: number;
}


@Component({
  selector: 'app-report-user-role-mapp',
  templateUrl: './report-user-role-mapp.component.html'
})
export class ReportUserRoleMappComponent implements OnInit {

  users: ReportUser[] = [];
  roles: ReportRole[] = [];
  @ViewChild('autoUser', { static: false }) autoUser: AutocompleteComponent;
  @ViewChild('autoRole', { static: false }) autoRole: AutocompleteComponent;
  createModel: ReportUserRole = new UserVsRoleModel();
  createForm: FormGroup;

  searchModel: UserVsRoleViewModel = new UserVsRoleViewModel();
  userRoleMapps: ReportUserRole[] = [];


  constructor(private formBuilder: RxFormBuilder, private service: ReportUserService, private notify: NotifyService) {
      this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  selectUser(item: ReportUser) {
    this.createForm.controls.userDomainId.setValue(item.id);
    this.createForm.controls.userDomainId.markAsDirty();
  }
  selectUserChange(value: string) {
    this.createForm.controls.userDomainId.setValue(value);
    this.createForm.controls.userDomainId.markAsDirty();
  }

  selectRole(item: ReportRole) {
    this.createForm.controls.roleId.setValue(item.id);
    this.createForm.controls.roleId.markAsDirty();
  }
  selectRoleChange(value: string) {
    this.createForm.controls.roleId.setValue(-1);
    this.createForm.controls.roleId.markAsDirty();
  }

  searchedUserVsRoles(): UserVsRoleViewModel[] {
    const values = this.mapp(this.userRoleMapps).filter(x =>
      x.userDomainId.toLowerCase().includes(this.searchModel.userDomainId.toLowerCase())
      && x.roleName.toLowerCase().includes(this.searchModel.roleName.toLowerCase())
    );
    return values;
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createUserRoleMapp(this.createModel)
    .subscribe((data) => {
      this.userRoleMapps.push(data);
      FormHelper.cleanAutocomplete(this.autoUser);
      FormHelper.cleanAutocomplete(this.autoRole);
      FormHelper.clean(this.createForm);

      this.notify.success("Role assigned to user.");
      this.notify.blockUi(false);
    },
    error => {
      if (HttpHelper.isValidationError(error)) {
        FormHelper.mappValidationErrors(this.createForm, error)
      } else {
        this.notify.error("Error to assign user to the  role.");
      }
      this.notify.blockUi(false);
    });
  }

  remove(item: UserVsRoleViewModel) {
    const index = this.userRoleMapps.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want remove user:'${item.userDomainId}' form role:'${item.roleName}'?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteUserRoleMapp(item.id).subscribe((data)=>{
            this.userRoleMapps.splice(index, 1);
            this.notify.success("User removed from the role.");
            this.notify.blockUi(false);
          },
          error => {
            this.notify.error("Unable to remove user from the role.");
            this.notify.blockUi(false);
          });
        }
      });
  }

  mapp(items: ReportUserRole[]): UserVsRoleViewModel[] {
    const mapps: UserVsRoleViewModel[] = [];
    items.forEach((m) => {
      const mapp = new UserVsRoleViewModel();
      mapp.id = m.id;
      mapp.userDomainId = m.userDomainId;
      mapp.roleName = this.roles.filter(x => x.id === m.roleId)[0].name
      mapps.push(mapp);
    });
    return mapps;
  }


  ngOnInit() {
    this.notify.blockUi();
    forkJoin([
      this.service.users(),
      this.service.roles(),
      this.service.userRoleMapps()
    ]).subscribe((res) => {
      this.users = res[0];
      this.roles = res[1];
      this.userRoleMapps = res[2];
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load page.");
      this.notify.blockUi(false);
    });
  }

  /*create form*/
  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }
}
