import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard, PermissionGuardService as PermissionGuard } from '../../services/auth-guard.service';

import { ChannelComponent } from './channel.component';
import { ReportRoleComponent } from './report-role.component';
import { ReportUserUsersComponent } from './report-user-users.component';
import { ReportUsersUploadComponent } from './report-users-upload.component';
import { ReportUserDelegatesComponent } from './report-user-delegates.component';
import { ReportUserHierarchiesComponent } from './report-user-hierarchies.component';
import { ReportUserRoleMappComponent } from './report-user-role-mapp.component';
import { ChannelPartnerComponent } from './channel-partner.component';
import { PermissionEnum } from '../../core/enum';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'User List'
    },
    children: [
      {
        path: '',
        redirectTo: 'users'
      },
      {
        path: 'channels',
        component: ChannelComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserChannel],
          title: 'Channel List'
        }
      },     
      {
        path: 'channel-partners',
        component: ChannelPartnerComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserChannelPartner],
          title: 'Channel Partner'
        }
      },
      {
        path: 'roles',
        component: ReportRoleComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportRole],
          title: 'Role List'
        }
      },
      {
        path: 'users',
        component: ReportUserUsersComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserList],
          title: 'User List'
        }
      },
      {
        path: 'users-upload',
        component: ReportUsersUploadComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserUpload],
          title: 'User Upload'
        }
      },
      {
        path: 'delegates',
        component: ReportUserDelegatesComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserDelegate],
          title: 'Delegate List'
        }
      },
      {
        path: 'hierarchies',
        component: ReportUserHierarchiesComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserHierarchy],
          title: 'Hierarchy List'
        }
      }, 
      {
        path: 'user-role-mapps',
        component: ReportUserRoleMappComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.ReportUserUserVsRole],
          title: 'User Vs Role'
        }
      },     
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportUserRoutingModule {}
