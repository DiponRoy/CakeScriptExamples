import { Component, OnInit } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportUserChannel } from '../../models/report-user.model';
import { NotifyService } from '../../utilities/notify.service';
import { RxFormBuilder, required, prop, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';


export class ChannelModel implements ReportUserChannel {
  @required()
  @maxLength({ value: 50 })
  id: string = "";
  @prop()
  @maxLength({ value: 250 })
  details: string = "";
}

@Component({
  selector: 'app-channel',
  templateUrl: './channel.component.html'
})
export class ChannelComponent implements OnInit {
  createModel: ChannelModel = new ChannelModel();
  createForm: FormGroup;

  searchName: string = "";
  list: ReportUserChannel[] = [];

  constructor(private formBuilder: RxFormBuilder, private service: ReportUserService, private notify: NotifyService) {
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  searchedItems(): ReportUserChannel[] {
    const values = this.list.filter(x =>
      x.id.toLowerCase().includes(this.searchName.toLowerCase())
    );
    return values;
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createChannel(this.createForm.value)
      .subscribe((data) => {
        this.list.push(data);
        this.notify.success("Channel created.");
        FormHelper.clean(this.createForm);
        this.notify.blockUi(false);
      },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create channel.");
          }
          this.notify.blockUi(false);
        });
  }

  remove(item: ReportUserChannel) {
    const index = this.list.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want to remove this channel?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteChannel(item.id)
          .subscribe((data) => {
            this.notify.success("Channel deleted.");
            this.list.splice(index, 1);

            this.notify.blockUi(false);
          },
          error => {
            if (HttpHelper.isValidationError(error)) {
              const msgs = FormHelper.fieldValidationErrors(error, 'id')
              const msg = msgs.length ? msgs[0] : "Unable to delete."
              this.notify.warning(msg);
            } else {
              this.notify.error("Unable to delete channel.");
            }
            this.notify.blockUi(false);
          });
        }
      });
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  ngOnInit() {
    this.notify.blockUi();
    this.service.channels().subscribe((data) => {
      this.list = data;
      this.notify.blockUi(false);
    },
      error => {
        this.notify.error("Unable to load channels.");
        this.notify.blockUi(false);
      });
  }
}