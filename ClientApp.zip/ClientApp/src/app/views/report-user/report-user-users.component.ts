import { Component, OnInit } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportRole, ReportUserRole, UserListViewModel, ReportUserDelegate, ReportUser, UserExportImportModel } from '../../models/report-user.model';

import { NgxSpinnerService } from 'ngx-spinner';
import { forkJoin } from 'rxjs';
import { ExcelService } from '../../utilities/excel.service';
import { Router } from '@angular/router';
import { NotifyService } from '../../utilities/notify.service';
import { CfsRouterService } from '../../services/cfs-router.service';

@Component({
  selector: 'app-report-user-user',
  templateUrl: './report-user-users.component.html'
})
export class ReportUserUsersComponent implements OnInit {
  searchDomainId: string = "";
  searchEmail: string = "";
  searchChannel: string = "";
  searchPartner: string = ""; 

  roles: ReportRole[] = [];
  users: ReportUser[] = [];
  userRoles: ReportUserRole[] = [];
  delegations: ReportUserDelegate[] = [];

  userDetails: UserListViewModel[] = [];

  constructor(private router: CfsRouterService, private service: ReportUserService, private excelService:ExcelService, private notify: NotifyService) {
  }

  searchedUserDetails(): UserListViewModel[] {
    const values = this.userDetails.filter(x =>
      x.user.id.toLowerCase().includes(this.searchDomainId.toLowerCase())
      && x.user.empEmail.toLowerCase().includes(this.searchEmail.toLowerCase())
      && x.user.channelName.toLowerCase().includes(this.searchChannel.toLowerCase())
      && x.user.partnerGpcName.toLowerCase().includes(this.searchPartner.toLowerCase())
    );
    return values;
  }

  findRoles(domainId: string): ReportRole[] {
    var list = [];
    var roleIds = this.userRoles
      .filter(x => x.userDomainId === domainId)
      .map(x => x.roleId);
    list = this.roles.filter(x => roleIds.includes(x.id));
    return list;
  }
  findDelegationsTo(domainId: string): ReportUser[] {
    var list = [];
    var userDomainIds = this.delegations
      .filter(x => x.delegateForm === domainId)
      .map(x => x.delegateTo);
      list = this.users.filter(x => userDomainIds.includes(x.id));
    return list;
  }

  mappDetails(): UserListViewModel[] {
    const list: UserListViewModel[] = [];
    this.users.forEach(x => {
      const userObj = new UserListViewModel();
      userObj.user = x;
      userObj.roles = this.findRoles(x.id);
      userObj.deletationToUsers = this.findDelegationsTo(x.id);
      list.push(userObj);
    });
    debugger;
    return list;
  }

  importAll(): void {
    this.router.reportUserUpload();
  }

  exportAll(): void {
    try{
      this.notify.blockUi();
      const list = this.exportList(this.userDetails);
      this.excelService.exportAsExcelFile(list, 'Users');  
      this.notify.blockUi(false);
    } catch(error) {
      this.notify.error("Error to export user list.");
      this.notify.blockUi(false);
      throw new Error(error);
    }
  }

  exportList(sourceList: UserListViewModel[]): UserExportImportModel[] {
    const list: UserExportImportModel[] = [];
    sourceList.forEach(x => {
      const m = new UserExportImportModel();
      m.set(x);
      list.push(m);
    });
    return list
  }
  
  ngOnInit() {
    this.notify.blockUi();
    
    forkJoin([
      this.service.users(),
      this.service.roles(),
      this.service.userRoleMapps(),
      this.service.delegations()
    ]).subscribe((res) => {
      this.users = res[0];
      this.roles = res[1];
      this.userRoles = res[2];
      this.delegations = res[3];
      this.userDetails = this.mappDetails();
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load the page.");
      this.notify.blockUi(false);
    });
  }
}
