import { Component, OnInit } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportRole } from '../../models/report-user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../utilities/notify.service';

@Component({
  selector: 'app-report-role',
  templateUrl: './report-role.component.html'
})
export class ReportRoleComponent implements OnInit {
  searchRoleName: string = "";
  list: ReportRole[] = [];

  constructor(private service: ReportUserService, private notify: NotifyService) { 
  }

  searchedRoles(): ReportRole[]{
    const values = this.list.filter(x => 
        x.name.toLowerCase().includes(this.searchRoleName.toLowerCase()) 
    );
    return values;
  }

  ngOnInit() {
    this.notify.blockUi();
    this.service.roles().subscribe((data) => {
      this.list = data;
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Unable to load roles.");
      this.notify.blockUi(false);
    });
  }
}