import { Component, OnInit } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportRole, ReportUserRole, ReportUser, ReportUserDelegate, UserListViewModel, UserExportImportModel, UserExportImport, ReportUserBulkUpload } from '../../models/report-user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { forkJoin } from 'rxjs';
import { ExcelService } from '../../utilities/excel.service';
import { NotifyService } from '../../utilities/notify.service';
import { CfsRouterService } from '../../services/cfs-router.service';
import { RxFormBuilder, digit, required, minNumber, propArray, maxNumber, extension, endsWith, prop, email, error, minLength, unique, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup, FormArray, AbstractControl } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { BsDatepickerViewMode } from 'ngx-bootstrap/datepicker/models';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { HttpErrorResponse } from '@angular/common/http';


export class BulkUserModel implements ReportUser {
  @required()
  @unique()
  @maxLength({ value: 50 })
  id: string;
  @required()
  @maxLength({ value: 50 })
  channelName: string;
  @prop()
  @maxLength({ value: 100 })
  partnerGpcName: string;
  @required()
  @maxLength({ value: 150 })
  empName: string
  @prop()
  @maxLength({ value: 150 })
  empEmail: string;
  @prop()
  @maxLength({ value: 50 })
  empId: string;  /*optional*/
  @required()
  @maxLength({ value: 200 })
  designation: string;
  @required()
  isSupervisor: boolean;
  @prop()
  @maxLength({ value: 50 })
  supervisorDomainName: string;

    setFromModel(model: UserExportImport) {
      this.empId = model.EmployeeId;
      this.id = model.DomainId;
      this.designation = model.Designation;
      this.channelName = model.ChannelName;
      this.partnerGpcName = model.PartnerName;
      this.empName = model.Name;
      this.empEmail = model.Email;
      this.isSupervisor = model.IsSupervisor;
      this.supervisorDomainName = model.SupervisorDomainId;
    }
} 

export class UserBulkUploadModel implements ReportUserBulkUpload {
  @required()
  date: Date = null;
  @required()
  file: File = null;

  @required()
  @digit()
  @minNumber({ value: 1, message: "Minimum value should be 1."})
  @maxNumber({ value: 12, message: "Maximum value should be 12."})
  month: number;
  @required()
  @digit()
  @minNumber({ value: 1, message: "Minimum value should be 1."})
  year: number;
  @propArray(BulkUserModel)
  users: Array<BulkUserModel> = [];
  @endsWith({ value:'.xlsx', message: "File format should be .xlsx" })
  sourceDetail: string = '';
}

@Component({
  selector: 'app-report-users-upload',
  templateUrl: './report-users-upload.component.html'
})
export class ReportUsersUploadComponent implements OnInit {
  showOnlyErrorRows: boolean = false;
  dpConfig: Partial<BsDatepickerConfig>;
  
  date: Date;
  minDate: Date = new Date();
  file: File;
  createForm: FormGroup;
  userFormlist: FormGroup[];


  constructor(private formBuilder: RxFormBuilder, private router: CfsRouterService, private notify: NotifyService, private service: ReportUserService, private excelService: ExcelService) {
    this.createForm = this.formBuilder.formGroup(new UserBulkUploadModel());
    this.userFormlist = [];
  }


  userUploadedItems(): FormGroup[] {
    let formgroups = this.userFormlist
    let list = this.showOnlyErrorRows ? formgroups.filter(x => x.invalid) : formgroups;
    return list;
  }

  dateChange(): void {
    this.createForm.controls.date.setValue(this.date);
    this.createForm.controls.month.setValue(this.date.getMonth()+1);
    this.createForm.controls.year.setValue(this.date.getFullYear()); 
    this.createForm.controls.date.markAsDirty();
    this.createForm.controls.month.markAsDirty();
    this.createForm.controls.year.markAsDirty();
  }

  setUserListToForm(users: UserExportImport[]) {
    // let forms = <FormArray>this.createForm.controls.users;
    // forms.clear();
    this.userFormlist = [];
    users.forEach( x => {     
      let model = new BulkUserModel();
      model.setFromModel(x)
      let form = this.formBuilder.formGroup<BulkUserModel>(model);
      this.userFormlist.push(form);
      FormHelper.startValidating(form);       
    });
  }

  importFile(event): void {
    this.setUserListToForm([]);
    this.createForm.controls.file.setValue(null);
    this.createForm.controls.file.markAsDirty();
    this.createForm.controls.sourceDetail.setValue('');
    this.createForm.controls.sourceDetail.markAsDirty();

    if(event.target.files.lenght < 1){
      return;
    }
    var file: File = event.target.files[0];
    this.file = event.target.files[0];
    this.createForm.controls.file.setValue(this.file);
    this.createForm.controls.sourceDetail.setValue('Ui:File:' + this.file.name);

    const fileReader = new FileReader();
    fileReader.onload = (e) => {
      this.notify.blockUi();

      const dataList = this.excelService.readFileAs<UserExportImport>(fileReader);
      debugger;
      var list: Array<UserExportImportModel> = [];
      dataList.forEach(x => {
        var m = new UserExportImportModel();
        m.setFromModel(x)
        list.push(m);
      });
      this.setUserListToForm(list);
    };
    fileReader.onloadstart = (e) => {
      this.notify.blockUi();
    };
    fileReader.onloadend = (e) => {
      this.notify.blockUi(false);
    };
    fileReader.onerror = (e) => {
      this.notify.blockUi(false);
      this.notify.error("Unable to load file.");
    };
    fileReader.readAsArrayBuffer(this.file);
  }

  uploadFile(): void {
    FormHelper.startValidating(this.createForm);
    let formgroups = this.userFormlist;
    formgroups.forEach(form => {
      FormHelper.startValidating(form);       
    });
    let hasErrorRows = formgroups.filter(x => x.invalid).length > 0;
    if (this.createForm.invalid || hasErrorRows) {  
      this.notify.warning('Validation error.');
      return;
    }
    if (formgroups.length < 1) {     
      this.notify.warning('No user found inside the uploaded file.');
      return;
    }

    this.notify.blockUi();
    var bulkUpload: ReportUserBulkUpload = {
      sourceDetail: this.createForm.controls.sourceDetail.value,
      month: this.createForm.controls.month.value,
      year: this.createForm.controls.year.value,
      users: this.userFormlist.map(x => x.value)
    };
    this.service.uploadUsers(bulkUpload).subscribe(data => {
      this.setUserListToForm([]);
      this.notify.success('Users uploaded.');
      this.notify.info("Redirecting to user list page.");
      setTimeout(() => {
        this.router.reportUsers();
      }, 300);
    }, error => {
      if (HttpHelper.isValidationError(error)) {
        this.showOnlyErrorRows = false;
        FormHelper.mappValidationErrors(this.createForm, error)        
        FormHelper.mappValidationErrorsToList(formgroups, "users", error);
        this.notify.warning('Validation error from server.');
      } else {
        this.notify.error('Error to upload file.');
      }
      this.notify.blockUi(false);  
    })
  }

  exportList(sourceList: UserListViewModel[]): UserExportImportModel[] {
    const list: UserExportImportModel[] = [];
    sourceList.forEach(x => {
      const m = new UserExportImportModel();
      m.set(x);
      list.push(m);
    });
    return list
  }

  /*create form*/
  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  ngOnInit() {
    /*datepicker*/
    let minMode: BsDatepickerViewMode = 'month';
    this.dpConfig = Object.assign({}, {
      minMode : minMode,
      dateInputFormat: 'MMMM, YYYY'
    });
  }
}
