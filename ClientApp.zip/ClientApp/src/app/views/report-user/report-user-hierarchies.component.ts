import { Component, OnInit } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportUserMonthlyHierarchy, MonthlyHierarchyModel } from '../../models/report-user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../utilities/notify.service';
import { BsDatepickerViewMode } from 'ngx-bootstrap/datepicker/models';
import { BsDatepickerConfig } from 'ngx-bootstrap';

@Component({
  selector: 'app-report-user-hierarchies',
  templateUrl: './report-user-hierarchies.component.html'
})
export class ReportUserHierarchiesComponent implements OnInit {
  dpConfig: Partial<BsDatepickerConfig>;
  searchDate: Date = new Date();
  searchModel: MonthlyHierarchyModel = new MonthlyHierarchyModel();
  hierarchies: ReportUserMonthlyHierarchy[] = [];

  constructor(private service: ReportUserService, private notify: NotifyService) {
  }

  searchedHierarchies(): ReportUserMonthlyHierarchy[] {
    const values = this.hierarchies.filter(x =>
      x.agentId.toLowerCase().includes(this.searchModel.agentId.toLowerCase())
    );
    return values;
  }

  loadHierarchies() {
    this.hierarchies = [];

    this.notify.blockUi();
    const month = this.searchDate.getMonth() + 1;   /*Date object: 0-11, Db:1-12*/
    const year = this.searchDate.getFullYear();
    this.service.monthlyHierarchies(month, year)
      .subscribe((data) => {
        this.hierarchies = data;
        this.notify.blockUi(false);
      },
      error => {
          this.notify.error("Unable to delete deletagion.");
          this.notify.blockUi(false);
      });
  }

  monthName(month: number): string {
    const date = new Date();
    date.setMonth(month - 1);   /*Date object: 0-11, Db:1-12*/
    const value = date.toLocaleString('default', { month: 'long' });
    return value;
  }

  ngOnInit() {
    /*datepicker*/
    let minMode: BsDatepickerViewMode = 'month';
    this.dpConfig = Object.assign({}, {
      minMode : minMode,
      dateInputFormat: 'MMMM, YYYY'
    });

    this.loadHierarchies();
  }
}
