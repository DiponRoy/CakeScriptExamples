import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportUserChannelPartner, ReportUserChannel } from '../../models/report-user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../utilities/notify.service';
import { AutocompleteComponent } from 'angular-ng-autocomplete';
import { RxFormBuilder, prop, required, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { forkJoin } from 'rxjs';

export class PartnerModel implements ReportUserChannelPartner {
  @prop()
  id: number = 0;
  @required()
  @maxLength({ value: 50 })
  channelId: string = "";
  @prop()
  @maxLength({ value: 100 })
  partnerName: string = "";
  @prop()
  @maxLength({ value: 250 })
  details: string = "";
}


@Component({
  selector: 'app-channel',
  templateUrl: './channel-partner.component.html'
})
export class ChannelPartnerComponent implements OnInit {
  @ViewChild('autoChannel', {static: false}) auto: AutocompleteComponent;
  channels: ReportUserChannel[] = [];

  createModel: PartnerModel = new PartnerModel();
  createForm: FormGroup;

  searchChannel: string = "";
  searchPartner: string = "";
  list: ReportUserChannelPartner[] = [];

  constructor(private formBuilder: RxFormBuilder, private service: ReportUserService, private spinner: NgxSpinnerService, private notify: NotifyService) { 
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  searchedItems(): ReportUserChannelPartner[]{
    const values = this.list.filter(x => 
      x.channelId.toLowerCase().includes(this.searchChannel.toLowerCase()) 
      && x.partnerName.toLowerCase().includes(this.searchPartner.toLowerCase()) 
    );
    return values;
  }

  selectChannel(item: ReportUserChannel) {
    this.createForm.controls.channelId.setValue(item.id);
    this.createForm.controls.channelId.markAsDirty();
  }
  channelChange(value: string) {
    this.createForm.controls.channelId.setValue(value);
    this.createForm.controls.channelId.markAsDirty();
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createChannelPartner(this.createForm.value)
    .subscribe((data) => {
      this.list.push(data);
      FormHelper.cleanAutocomplete(this.auto);
      FormHelper.clean(this.createForm);  

      this.notify.success("Channel partner created.");
      this.notify.blockUi(false);
    },
    error => {
      if (HttpHelper.isValidationError(error)) {
        FormHelper.mappValidationErrors(this.createForm, error)
      } else {
        this.notify.error("Unable to create channel partner.");
      }
      this.notify.blockUi(false);
    });
  }

  remove(item: ReportUserChannelPartner) {
    const index = this.list.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want to remove this channel partner?`)
    .then((confirm) => {
      if (confirm) {
        this.service.deleteChannelPartner(item.id).subscribe((data)=>{
          this.notify.success("Channel partner deleted.");
          this.list.splice(index, 1);

          this.notify.blockUi(false);
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            const msgs = FormHelper.fieldValidationErrors(error, 'id')
            const msg = msgs.length ? msgs[0] : "Unable to delete."
            this.notify.warning(msg);
          } else {
            this.notify.error("Unable to delete channel partner.");
          }
          this.notify.blockUi(false);
        });
      }
    });
}

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  ngOnInit() {
    this.notify.blockUi();
    forkJoin([this.service.channels(), this.service.channelPartners()]).subscribe(
      (res) => {
      this.channels = res[0];
      this.list = res[1];
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load page.");
      this.notify.blockUi(false);
    });
  }
}