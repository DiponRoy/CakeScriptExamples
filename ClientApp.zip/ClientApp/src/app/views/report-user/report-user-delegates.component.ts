import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportUserModel, ReportUserDelegate, ReportUser, DelegationModel } from '../../models/report-user.model';
import { ReportUserService } from '../../services/report-user.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ConfirmDialogService } from '../../elements/confirm-dialog/confirm-dialog.service';
import { forkJoin } from 'rxjs';
import { NotifyService } from '../../utilities/notify.service';
import { required, prop, RxFormBuilder } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { HttpHelper, FormHelper } from '../../utilities/form.helper';
import { AutocompleteComponent } from 'angular-ng-autocomplete';


export class ReportUserDelegateModel implements ReportUserDelegate {
  @prop()
  id: number = 0;
  @required()
  delegateForm: string = '';
  @required()
  delegateTo: string = '';
}

@Component({
  selector: 'app-report-user-delegates',
  templateUrl: './report-user-delegates.component.html'
})
export class ReportUserDelegatesComponent implements OnInit {
  /*create new*/
  users: ReportUser[] = [];           /*ng-autocomplete data sample [{id: '', name: ''}]*/
  @ViewChild('autoFrom', { static: false }) autoFrom: AutocompleteComponent;
  @ViewChild('autoTo', { static: false }) autoTo: AutocompleteComponent;
  createModel: ReportUserDelegate = new ReportUserDelegateModel();
  createForm: FormGroup;

  /*list*/
  searchModel: ReportUserDelegate = new DelegationModel();
  delegations: ReportUserDelegate[] = [];

  constructor(private formBuilder: RxFormBuilder, private service: ReportUserService, private notify: NotifyService) {
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  selectFromDelegate(item: ReportUser) {
    this.createForm.controls.delegateForm.setValue(item.id);
    this.createForm.controls.delegateForm.markAsDirty();
  }
  selectFromDelegateChange(value: string) {
    this.createForm.controls.delegateForm.setValue(value);
    this.createForm.controls.delegateForm.markAsDirty();
  }

  selectToDelegate(item: ReportUser) {
    this.createForm.controls.delegateTo.setValue(item.id);
    this.createForm.controls.delegateTo.markAsDirty();
  }
  selectToDelegateChange(value: string) {
    this.createForm.controls.delegateTo.setValue(value);
    this.createForm.controls.delegateTo.markAsDirty();
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createDelegation(this.createForm.value).subscribe(
      (data) => {
        this.delegations.push(data);
        FormHelper.cleanAutocomplete(this.autoFrom);
        FormHelper.cleanAutocomplete(this.autoTo);
        FormHelper.clean(this.createForm);

        this.notify.success("Deletagion created.");
        this.notify.blockUi(false);
      },
      error => {
        if (HttpHelper.isValidationError(error)) {
          FormHelper.mappValidationErrors(this.createForm, error)
        } else {
          this.notify.error("Error to create deletagion.");
        }
        this.notify.blockUi(false);
      });
  }

  searchedDelegations() {
    const values = this.delegations.filter(x =>
      x.delegateForm.toLowerCase().includes(this.searchModel.delegateForm.toLowerCase())
      && x.delegateTo.toLowerCase().includes(this.searchModel.delegateTo.toLowerCase())
    );
    return values;
  }

  remove(item: ReportUserDelegate) {
    const index = this.delegations.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want to remove this deletagion?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteDelegation(item.id).subscribe((data) => {
            this.delegations.splice(index, 1);
            this.notify.success("Deletagion removed.");
            this.notify.blockUi(false);
          },
          error => {
              this.notify.error("Unable to delete deletagion.");
              this.notify.blockUi(false);
          });
        }
      });
  }

  ngOnInit() {
    this.notify.blockUi();
    forkJoin([this.service.users(), this.service.delegations()]).subscribe(
      (res) => {
        this.users = res[0];
        this.delegations = res[1];
        this.notify.blockUi(false);
      },
      error => {
        this.notify.error("Error to load page.");
        this.notify.blockUi(false);
      });
  }

  /*create*/
  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }
}
