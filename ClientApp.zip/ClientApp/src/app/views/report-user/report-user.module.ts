import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';

import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CollapseModule } from 'ngx-bootstrap/collapse';


import { ReportUserRoutingModule } from './report-user-routing.module';
import { ReportRoleComponent } from './report-role.component';
import { ReportUserUsersComponent } from './report-user-users.component';
import { ReportUsersUploadComponent } from './report-users-upload.component';
import { ReportUserDelegatesComponent } from './report-user-delegates.component';
import { ReportUserHierarchiesComponent } from './report-user-hierarchies.component';
import { ReportUserRoleMappComponent } from './report-user-role-mapp.component';
import { ChannelComponent } from './channel.component';
import { ChannelPartnerComponent } from './channel-partner.component';

// Angular

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    CollapseModule.forRoot(),
    AutocompleteLibModule,
    BsDatepickerModule.forRoot(),


    ReportUserRoutingModule,
  ],
  declarations: [
    ChannelComponent,
    ChannelPartnerComponent,
    ReportRoleComponent,
    ReportUserUsersComponent,
    ReportUsersUploadComponent,
    ReportUserDelegatesComponent,
    ReportUserHierarchiesComponent,
    ReportUserRoleMappComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ReportUserModule { }
