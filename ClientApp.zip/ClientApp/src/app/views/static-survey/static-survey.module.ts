import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// Collapse Component
import { CollapseModule } from 'ngx-bootstrap/collapse';
//import { CollapsesComponent } from './collapses.component';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ModalModule, PopoverModule, TimepickerModule } from 'ngx-bootstrap';

import { StaticSurveyRoutingModule } from './static-survey-routing.module';
import { QuestionChannelComponent } from './question-channel.component';
import { QuestionSetsComponent } from './question-sets.component';
import { QuestionSetDetailsComponent } from './question-set-details.component';
import { QuestionCreateDialogComponent } from './dialogs/question-create-dialog.component';
import { QuestionSetUpdateDialogComponent } from './dialogs/question-set-update-dialog.component';
import { QuestionUpdateDialogComponent } from './dialogs/question-update-dialog.component';
import { QuestionOptionCreateDialogComponent } from './dialogs/question-option-create-dialog.component';
import { QuestionOptionUpdateDialogComponent } from './dialogs/question-option-update-dialog.component';
import { ChildQuestionCreateDialogComponent } from './dialogs/child-question-create-dialog.component';
import { ChildQuestionUpdateDialogComponent } from './dialogs/child-question-update-dialog.component';



// Angular
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
    CollapseModule.forRoot(),
    AutocompleteLibModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    ModalModule.forRoot(),
    PopoverModule.forRoot(),

    StaticSurveyRoutingModule,
  ],
  declarations: [    
    QuestionChannelComponent,
    QuestionSetsComponent,

    QuestionSetUpdateDialogComponent,
    QuestionCreateDialogComponent,
    ChildQuestionCreateDialogComponent,
    QuestionUpdateDialogComponent,
    QuestionOptionCreateDialogComponent,
    ChildQuestionUpdateDialogComponent,
    QuestionOptionUpdateDialogComponent,

    QuestionSetDetailsComponent    
  ],
  entryComponents: [
    QuestionSetUpdateDialogComponent,
    QuestionCreateDialogComponent,
    ChildQuestionCreateDialogComponent,
    QuestionUpdateDialogComponent,
    QuestionOptionCreateDialogComponent,
    ChildQuestionUpdateDialogComponent,
    QuestionOptionUpdateDialogComponent
  ], 

  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class StaticSurveyModule { }
