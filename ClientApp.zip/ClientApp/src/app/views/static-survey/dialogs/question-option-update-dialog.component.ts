import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { QuestionAnswerOption, StaticSurveyService } from '../../../services/static-survey.service';
import { RxFormBuilder, required, digit, prop, minNumber, maxLength } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';

export class QuestionAnswerOptionModel implements QuestionAnswerOption {
  @required()
  @digit()
  answerId: number = 0;
  @required()
  @digit()
  questionSetId: number = 0;
  @required()
  @digit()
  questionId: number = 0;
  @required()
  @maxLength({ value: 100 })
  answerOptionText: string = '';
  @prop()
  @maxLength({ value: 100 })
  answerOptionTextBn: string = '';
  @required()
  @digit()
  @minNumber({ value: 1 })
  answerOptionRating: number;
}

@Component({
  selector: 'app-question-option-update-dialog',
  templateUrl: './question-option-update-dialog.component.html'
})
export class QuestionOptionUpdateDialogComponent {

  updateForm: FormGroup;
  afterUpdate: EventEmitter<QuestionAnswerOption> = new EventEmitter();

  constructor(private bsModalRef: BsModalRef, private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService) { 
    this.updateForm = this.formBuilder.formGroup(new QuestionAnswerOptionModel());
  }

  public update() {
    FormHelper.startValidating(this.updateForm);
    if (this.updateForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.updateAnswerOption(this.updateForm.value)
      .subscribe(
        (data) => {
          this.notify.success("Question option updated.");
          FormHelper.clean(this.updateForm);
          this.notify.blockUi(false);

          this.afterUpdate.emit(data);
          this.dismiss();
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.updateForm, error)
          } else {
            this.notify.error("Unable to update question option.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  public dismiss() {
    this.bsModalRef.hide();
  }

  public setOption(option: QuestionAnswerOption) {
    this.updateForm.controls.answerId.setValue(option.answerId);
    this.updateForm.controls.questionSetId.setValue(option.questionSetId);
    this.updateForm.controls.questionId.setValue(option.questionId);
    this.updateForm.controls.answerOptionText.setValue(option.answerOptionText);
    this.updateForm.controls.answerOptionTextBn.setValue(option.answerOptionTextBn);
    this.updateForm.controls.answerOptionRating.setValue(option.answerOptionRating);
    FormHelper.removeControlErrors(this.updateForm);
  }
}