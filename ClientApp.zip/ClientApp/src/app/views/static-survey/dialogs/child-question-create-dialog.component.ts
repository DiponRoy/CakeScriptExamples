import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { QuestionAnswerOption, StaticSurveyService, Question, QuestionSet, SurveyQuestionHierarchy, ChildQuestion } from '../../../services/static-survey.service';
import { RxFormBuilder, required, digit, prop, maxLength } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';

export class QuestionModel implements ChildQuestion {
  @required()
  @digit()
  parentQuestionId: number;
  @digit()
  questionId: number;
  @required()
  @digit()
  questionSetId: number;
  @prop()
  questionNo: number;
  @required()
  @digit()
  childQuestionNo ?: number = null;
  @required()
  @maxLength({ value: 50 })
  questionType: string;
  @required()
  @maxLength({ value: 300 })
  question: string;
  @prop()
  @maxLength({ value: 300 })
  questionBn: string;
  @prop()
  hasChildQuestion: boolean = false;
  @prop()
  parentQuestionNo?: number = null;
  @required()
  @maxLength({ value: 50 })
  answerType: string;
  @prop()
  entryTime: Date;
}

@Component({
  selector: 'app-child-question-create-dialog',
  templateUrl: './child-question-create-dialog.component.html'
})
export class ChildQuestionCreateDialogComponent {

  createForm: FormGroup;
  afterAdd: EventEmitter<SurveyQuestionHierarchy> = new EventEmitter();

  constructor(private bsModalRef: BsModalRef, private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService) { 
    this.createForm = this.formBuilder.formGroup(new QuestionModel());
  }

  public create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.createChildQuestion(this.createForm.value)
      .subscribe(
        (data) => {
          this.notify.success("Child question created.");
          FormHelper.clean(this.createForm);
          this.notify.blockUi(false);

          this.afterAdd.emit(data);
          this.dismiss();
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create child question.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  public dismiss() {
    this.bsModalRef.hide();
  }

  public setParent(option: Question) {
    this.createForm.controls.parentQuestionNo.setValue(option.questionNo);
    this.createForm.controls.parentQuestionId.setValue(option.questionId); 
    this.createForm.controls.questionSetId.setValue(option.questionSetId);
    FormHelper.removeControlErrors(this.createForm);
  }
}