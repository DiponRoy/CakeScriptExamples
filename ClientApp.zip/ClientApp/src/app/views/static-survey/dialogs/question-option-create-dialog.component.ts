import { Component, Input, OnInit, Output, EventEmitter, AfterContentInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { QuestionAnswerOption, StaticSurveyService, Question } from '../../../services/static-survey.service';
import { RxFormBuilder, required, digit, prop, minNumber, maxLength } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';

export class QuestionAnswerOptionModel implements QuestionAnswerOption {
  @prop()
  answerId: number = 0;
  @required()
  @digit()
  questionSetId: number = 0;
  @required()
  @digit()
  questionId: number = 0;
  @required()
  @maxLength({ value: 100 })
  answerOptionText: string = '';
  @prop()
  @maxLength({ value: 100 })
  answerOptionTextBn: string = '';
  @required()
  @digit()
  @minNumber({ value: 1 })
  answerOptionRating: number;
}

@Component({
  selector: 'app-question-option-create-dialog',
  templateUrl: './question-option-create-dialog.component.html'
})
export class QuestionOptionCreateDialogComponent {
  createForm: FormGroup;
  afterAdd: EventEmitter<QuestionAnswerOption> = new EventEmitter();

  constructor(private bsModalRef: BsModalRef, private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService) { 
    this.createForm = this.formBuilder.formGroup(new QuestionAnswerOptionModel());
  }

  public create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.createAnswerOption(this.createForm.value)
      .subscribe(
        (data) => {
          this.notify.success("Question option created.");
          FormHelper.clean(this.createForm);
          this.notify.blockUi(false);

          this.afterAdd.emit(data);
          this.dismiss();
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create question option.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  public dismiss() {
    this.bsModalRef.hide();
  }

  public setQuestion(option: Question) {
    this.createForm.controls.questionSetId.setValue(option.questionSetId);
    this.createForm.controls.questionId.setValue(option.questionId);
    FormHelper.removeControlErrors(this.createForm);
  }
}