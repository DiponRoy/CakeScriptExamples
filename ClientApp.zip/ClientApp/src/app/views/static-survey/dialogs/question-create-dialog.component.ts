import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { QuestionAnswerOption, StaticSurveyService, Question, QuestionSet } from '../../../services/static-survey.service';
import { RxFormBuilder, required, digit, prop, minNumber, maxLength } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';

export class QuestionCreateModel implements Question {
  @digit()
  questionId: number;
  @required()
  @digit()
  questionSetId: number;
  @required()
  @digit()
  @minNumber({value: 1, message: "Minimum value shoud be 1"})
  questionNo: number;
  @prop()
  childQuestionNo ?: number = null;
  @required()
  @maxLength({ value: 50 })
  questionType: string;
  @required()
  @maxLength({ value: 300 })
  question: string;
  @prop()
  @maxLength({ value: 300 })
  questionBn: string;
  @prop()
  hasChildQuestion: boolean = false;
  @prop()
  parentQuestionNo?: number = null;
  @required()
  @maxLength({ value: 50 })
  answerType: string;
  @prop()
  entryTime: Date;
}

@Component({
  selector: 'app-question-create-dialog',
  templateUrl: './question-create-dialog.component.html'
})
export class QuestionCreateDialogComponent {
  createForm: FormGroup;
  afterAdd: EventEmitter<Question> = new EventEmitter();

  constructor(private bsModalRef: BsModalRef, private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService) { 
    this.createForm = this.formBuilder.formGroup(new QuestionCreateModel());
  }

  public create() {
    FormHelper.startValidating(this.createForm);
    debugger;
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.createQuestion(this.createForm.value)
      .subscribe(
        (data) => {
          this.notify.success("Question created.");
          FormHelper.clean(this.createForm);
          this.notify.blockUi(false);

          this.afterAdd.emit(data);
          this.dismiss();
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create question.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  public dismiss() {
    this.bsModalRef.hide();
  }

  public setQuestionSet(option: QuestionSet) {
    this.createForm.controls.questionSetId.setValue(option.id);
    FormHelper.removeControlErrors(this.createForm);
  }
}