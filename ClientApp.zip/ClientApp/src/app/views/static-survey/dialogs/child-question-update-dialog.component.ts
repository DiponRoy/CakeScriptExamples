import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { QuestionAnswerOption, StaticSurveyService, Question, QuestionSet } from '../../../services/static-survey.service';
import { RxFormBuilder, required, digit, prop, minNumber, maxLength } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../../utilities/form.helper';

export class QuestionModel implements Question {
  @required()
  @digit()
  questionId: number;
  @required()
  @digit()
  questionSetId: number;
  @required()
  @digit()
  @minNumber({value: 1, message: "Minimum value shoud be 1"})
  questionNo: number;
  @required()
  @digit()
  @minNumber({value: 1, message: "Minimum value shoud be 1"})
  childQuestionNo ?: number = null;
  @required()
  @maxLength({ value: 50 })
  questionType: string;
  @required()
  @maxLength({ value: 300 })
  question: string;
  @prop()
  @maxLength({ value: 300 })
  questionBn: string;
  @prop()
  hasChildQuestion: boolean = false;
  @prop()
  parentQuestionNo?: number = null;
  @required()
  @maxLength({ value: 50 })
  answerType: string;
  @prop()
  entryTime: Date;
}

@Component({
  selector: 'app-child-question-update-dialog',
  templateUrl: './child-question-update-dialog.component.html'
})
export class ChildQuestionUpdateDialogComponent {

  updateForm: FormGroup;
  afterUpdate: EventEmitter<Question> = new EventEmitter();

  constructor(private bsModalRef: BsModalRef, private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService) { 
    this.updateForm = this.formBuilder.formGroup(new QuestionModel());
  }

  public update() {
    FormHelper.startValidating(this.updateForm);
    if (this.updateForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.updateChildQuestion(this.updateForm.value)
      .subscribe(
        (data) => {
          this.notify.success("Question updated.");
          FormHelper.clean(this.updateForm);
          this.notify.blockUi(false);

          this.afterUpdate.emit(data);
          this.dismiss();
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.updateForm, error)
          } else {
            this.notify.error("Unable to update question.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  public dismiss() {
    this.bsModalRef.hide();
  }

  public setQuestion(option: Question) {
    this.updateForm.controls.questionId.setValue(option.questionId);
    this.updateForm.controls.questionSetId.setValue(option.questionSetId);
    this.updateForm.controls.questionNo.setValue(option.questionNo);
    this.updateForm.controls.questionType.setValue(option.questionType);
    this.updateForm.controls.answerType.setValue(option.answerType);
    this.updateForm.controls.question.setValue(option.question);
    this.updateForm.controls.questionBn.setValue(option.questionBn);
    this.updateForm.controls.childQuestionNo.setValue(option.childQuestionNo);
    this.updateForm.controls.parentQuestionNo.setValue(option.parentQuestionNo);

    // this.updateForm.controls.hasChildQuestion.setValue(option.hasChildQuestion);
    // this.updateForm.controls.entryTime.setValue(option.entryTime);
    FormHelper.removeControlErrors(this.updateForm);
  }
}