import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { QuestionSet, StaticSurveyService } from '../../../services/static-survey.service';
import { RxFormBuilder, required, digit, minNumber, maxLength, prop } from '@rxweb/reactive-form-validators';
import { NotifyService } from '../../../utilities/notify.service';
import { FormGroup } from '@angular/forms';
import { HttpHelper, FormHelper } from '../../../utilities/form.helper';

export class QuestionSetModel implements QuestionSet {
  @required()
  @digit()
  @minNumber({value: 1, message: "Minimum value shoud be 1"})
  id: number;
  @required()
  @maxLength({ value: 300 })
  title: string = '';
  @required()
  @maxLength({ value: 50 })
  channelName: string = '';
  @prop()
  createDateTime: Date = new Date();
}

@Component({
  selector: 'app-question-set-update-dialog',
  templateUrl: './question-set-update-dialog.component.html'
})
export class QuestionSetUpdateDialogComponent {
  updateForm: FormGroup;
  afterUpdate: EventEmitter<QuestionSet> = new EventEmitter();

  constructor(private bsModalRef: BsModalRef, private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService) { 
    this.updateForm = this.formBuilder.formGroup(new QuestionSetModel());
  }


  public update() {
    FormHelper.startValidating(this.updateForm);
    if (this.updateForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.updateQuestionSet(this.updateForm.value)
      .subscribe(
        (data) => {
          this.notify.success("Question set updated.");
          FormHelper.clean(this.updateForm);
          this.notify.blockUi(false);

          this.afterUpdate.emit(data);
          this.dismiss();
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.updateForm, error)
          } else {
            this.notify.error("Unable to update question set.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  public dismiss() {
    this.bsModalRef.hide();
  }

  public setValues(set: QuestionSet) {
    this.updateForm.controls.id.setValue(set.id);
    this.updateForm.controls.title.setValue(set.title);
    this.updateForm.controls.channelName.setValue(set.channelName);
    FormHelper.removeControlErrors(this.updateForm);
  }
}