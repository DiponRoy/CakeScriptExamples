import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportRole } from '../../models/report-user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { StaticSurveyService, QuestionSet, QuestionSetChannel } from '../../services/static-survey.service';
import { NotifyService } from '../../utilities/notify.service';
import { prop, required, RxFormBuilder, digit, minNumber, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { forkJoin } from 'rxjs';
import { AutocompleteComponent } from 'angular-ng-autocomplete';
import { CfsRouterService } from '../../services/cfs-router.service';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { DateTimeHelper } from '../../utilities/dateTime.helper';


export class QuestionSetModel implements QuestionSet {
  @required()
  @digit()
  @minNumber({ value: 1 })
  id: number
  @required()
  @maxLength({ value: 300 })
  title: string
  @required()
  @maxLength({ value: 50 })
  channelName: string
  @prop()
  createDateTime: Date
}

@Component({
  selector: 'app-question-sets',
  templateUrl: './question-sets.component.html'
})
export class QuestionSetsComponent implements OnInit {
  channels: QuestionSetChannel[] = [];
  @ViewChild('autoChannel', { static: false }) autoChannel: AutocompleteComponent;
  createModel: QuestionSetModel = new QuestionSetModel();
  createForm: FormGroup;

  dpConfig: Partial<BsDatepickerConfig>;
  searchFromDate?: Date = null;
  searchToDate?: Date = null;
  searchChannelName: string = "";
  searchTitle: string = "";
  list: QuestionSet[] = [];

  constructor(private formBuilder: RxFormBuilder, private surveyService: StaticSurveyService, private notify: NotifyService, private router: CfsRouterService) {
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  selectChannel(item: QuestionSetChannel) {
    this.createForm.controls.channelName.setValue(item.id);
    this.createForm.controls.channelName.markAsDirty();
  }
  selectChannelChange(value: string) {
    this.createForm.controls.channelName.setValue(value);
    this.createForm.controls.channelName.markAsDirty();
  }

  searchedItems(): QuestionSet[] {
    var values = this.list.filter(x =>
      (this.searchFromDate == null || DateTimeHelper.date(this.searchFromDate) <= DateTimeHelper.date(x.createDateTime))
      && (this.searchToDate == null || DateTimeHelper.date(x.createDateTime) <= DateTimeHelper.date(this.searchToDate))
      && x.channelName.toLowerCase().includes(this.searchChannelName.toLowerCase())
      && x.title.toLowerCase().includes(this.searchTitle.toLowerCase())
    ).sort(x => x.id);
    return values;
  }

  view(item: QuestionSet) {
    this.router.viewQuestionSet(item.id);     
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.surveyService.createQuestionSet(this.createForm.value)
      .subscribe(
        (data) => {
          this.list.push(data);
          this.notify.success("Question set created.");
          FormHelper.cleanAutocomplete(this.autoChannel);
          FormHelper.clean(this.createForm);
          this.notify.blockUi(false);
        },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create question set.");
          }
          this.notify.blockUi(false);
        }
      );
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  dateString(dateTime: Date): string {
    let value: string = DateTimeHelper.dateString(dateTime);
    return value;
  }

  clearFromDate(){
    this.searchFromDate = null;
  }
  clearToDate(){
    this.searchToDate = null;
  }

  ngOnInit() {
    const dateFormat:string = DateTimeHelper.dateStringFormat;
    this.dpConfig = Object.assign({}, {
      dateInputFormat: dateFormat
    });

    /*load*/
    this.notify.blockUi();
    forkJoin([
      this.surveyService.channels(),
      this.surveyService.questionSets(),
    ]).subscribe((res) => {
      this.channels = res[0];
      this.list = res[1];
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load page.");
      this.notify.blockUi(false);
    });
  }
}