import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifyService } from '../../utilities/notify.service';
import { QuestionSetChannel, StaticSurveyService } from '../../services/static-survey.service';
import { required, RxFormBuilder, prop, maxLength } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';


export class QuestionSetModel implements QuestionSetChannel {
  @required()
  @maxLength({ value: 30 })
  id: string = '';
  @prop()
  @maxLength({ value: 250 })
  details: string = '';
}


@Component({
  selector: 'app-question-channel',
  templateUrl: './question-channel.component.html'
})
export class QuestionChannelComponent implements OnInit {

  createModel: QuestionSetModel = new QuestionSetModel();
  createForm: FormGroup;

  searchName: string = "";
  list: QuestionSetChannel[] = [];

  constructor(private formBuilder: RxFormBuilder, private service: StaticSurveyService, private notify: NotifyService) {
    this.createForm = this.formBuilder.formGroup(this.createModel);
  }

  searchedItems(): QuestionSetChannel[] {
    const values = this.list.filter(x =>
      x.id.toLowerCase().includes(this.searchName.toLowerCase())
    );
    return values;
  }

  create() {
    FormHelper.startValidating(this.createForm);
    if (this.createForm.invalid) {
      return;
    }

    this.notify.blockUi();
    this.service.createChannel(this.createForm.value)
      .subscribe((data) => {
        this.list.push(data);
        this.notify.success("Channel created.");
        FormHelper.clean(this.createForm);
        this.notify.blockUi(false);
      },
        error => {
          if (HttpHelper.isValidationError(error)) {
            FormHelper.mappValidationErrors(this.createForm, error)
          } else {
            this.notify.error("Unable to create.");
          }
          this.notify.blockUi(false);
        });
  }

  remove(item: QuestionSetChannel) {
    const index = this.list.findIndex(x => x.id === item.id);
    this.notify.ask(`Do you want to remove this channel?`)
      .then((confirm) => {
        if (confirm) {
          this.notify.blockUi();
          this.service.deleteChannel(item.id).subscribe((data) => {
            this.notify.success("Channel deleted.");
            this.list.splice(index, 1);
            this.notify.blockUi(false);
          },
            error => {
              if (HttpHelper.isValidationError(error)) {
                const msgs = FormHelper.fieldValidationErrors(error, 'id')
                const msg = msgs.length ? msgs[0] : "Unable to delete."
                this.notify.warning(msg);
              } else {
                this.notify.error("Unable to delete channel.");
              }
              this.notify.blockUi(false);
            });
        }
      });
  }

  isCollapsed: boolean = true;
  iconCollapse: string = 'icon-arrow-down';
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
    this.iconCollapse = this.isCollapsed ? 'icon-arrow-down' : 'icon-arrow-up';
  }

  ngOnInit() {
    this.notify.blockUi();
    this.service.channels().subscribe((data) => {
      this.list = data;
      this.notify.blockUi(false);
    },
      error => {
        this.notify.error("Unable to load page.");
        this.notify.blockUi(false);
      });
  }
}