import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard, PermissionGuardService as PermissionGuard } from '../../services/auth-guard.service';


import { QuestionSetsComponent } from './question-sets.component';
import { QuestionChannelComponent } from './question-channel.component';
import { QuestionSetDetailsComponent } from './question-set-details.component';
import { PermissionEnum } from '../../core/enum';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Question Sets'
    },
    children: [
      {
        path: '',
        redirectTo: 'question-sets'
      },
      {
        path: 'question-channels',
        component: QuestionChannelComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.StaticSurveyChannel],
          title: 'Question channels'
        }
      },
      {
        path: 'question-sets',
        component: QuestionSetsComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.StaticSurveyQuestionSetList],
          title: 'Question Sets'
        }
      },
      {
        path: 'question-set-details',
        component: QuestionSetDetailsComponent,
        canActivate: [AuthGuard, PermissionGuard],
        data: {
          permissions: [PermissionEnum.StaticSurveyQuestionSetModify],
          title: 'Details'
        }
      }     
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StaticSurveyRoutingModule {}
