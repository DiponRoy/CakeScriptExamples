import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportUserService } from '../../services/report-user.service';
import { ReportRole } from '../../models/report-user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { StaticSurveyService, QuestionSet, QuestionSetChannel, Question, QuestionAnswerOption, SurveyQuestionHierarchy } from '../../services/static-survey.service';
import { NotifyService } from '../../utilities/notify.service';
import { prop, required, RxFormBuilder, digit } from '@rxweb/reactive-form-validators';
import { FormGroup } from '@angular/forms';
import { FormHelper, HttpHelper } from '../../utilities/form.helper';
import { forkJoin } from 'rxjs';
import { AutocompleteComponent } from 'angular-ng-autocomplete';
import { ActivatedRoute } from '@angular/router';
import { BsModalService, BsModalRef, ModalOptions } from 'ngx-bootstrap';
import { QuestionCreateDialogComponent } from './dialogs/question-create-dialog.component';
import { QuestionSetUpdateDialogComponent } from './dialogs/question-set-update-dialog.component';
import { QuestionUpdateDialogComponent } from './dialogs/question-update-dialog.component';
import { QuestionOptionCreateDialogComponent } from './dialogs/question-option-create-dialog.component';
import { QuestionOptionUpdateDialogComponent } from './dialogs/question-option-update-dialog.component';
import { ChildQuestionCreateDialogComponent } from './dialogs/child-question-create-dialog.component';
import { CfsRouterService } from '../../services/cfs-router.service';
import { ChildQuestionUpdateDialogComponent } from './dialogs/child-question-update-dialog.component';


export class QuestionSetModel implements QuestionSet {
  id: number = 0;
  title: string = "";
  channelName: string = "";
  createDateTime: Date = new Date();
}

@Component({
  selector: 'app-question-set-details',
  templateUrl: './question-set-details.component.html'
})
export class QuestionSetDetailsComponent implements OnInit {
  config: ModalOptions = {
    backdrop: true,
    ignoreBackdropClick: true /*stop popup close on click*/
  };

  questionSet: QuestionSet = new QuestionSetModel();
  questions: Question[] = [];
  questionAnswerOptions: QuestionAnswerOption[] = [];

  constructor(private modalService: BsModalService,
    private service: StaticSurveyService, 
    private notify: NotifyService, 
    private route: ActivatedRoute,
    private router: CfsRouterService) {
  }

  getParentQuestions(): Question[] {
    let list = this.questions.filter(x => x.parentQuestionNo == null || x.parentQuestionNo == 0)
    .sort(x => x.questionNo);
    return list;
  }
  getChildQuestions(question: Question): Question[] {
    const list = this.questions
    .filter(x => x.parentQuestionNo != null && x.parentQuestionNo == question.questionNo)
    .sort(x => x.childQuestionNo);
    return list;
  }
  getAnswerOptions(questionId: number): QuestionAnswerOption[] {
    const list = this.questionAnswerOptions
    .filter(x => x.questionId == questionId)
    .sort(x => x.answerOptionRating);
    return list;
  }

  addQuestion(item: Question) {
    this.questions.push(item);
  }
  addOption(item: QuestionAnswerOption) {
    this.questionAnswerOptions.push(item);
  }
  deleteQuestion(item: Question) {
    const index = this.questions.findIndex(x => x.questionId === item.questionId);
    this.questions.splice(index, 1);
  }
  deleteOption(item: QuestionAnswerOption) {
    const index = this.questionAnswerOptions.findIndex(x => x.answerId === item.answerId);
    this.questionAnswerOptions.splice(index, 1);
  }

  upsertQuestion(item: Question) {
    this.deleteQuestion(item);
    this.questions.push(item);
  }
  upsertOption(item: QuestionAnswerOption) {
    this.deleteOption(item);
    this.questionAnswerOptions.push(item);
  }




  showToUpdateQuestionSet() {
    const bsModalRef = this.modalService.show(QuestionSetUpdateDialogComponent, this.config);
    bsModalRef.content.setValues(this.questionSet);
    bsModalRef.content.afterUpdate.subscribe(model => {
      this.questionSet = model;
    });
  }
  canDeleteQuestionSet(): boolean {
    var value = this.questions.filter(x => x.questionSetId == this.questionSet.id).length ? false : true;
    return value
  }
  confirmToDeleteQuestionSet() {
    this.notify.ask(`Do you want to delte this question set?`)
    .then((confirm) => {
      if (confirm) {
        this.notify.blockUi();
        this.service.removeQuestionSet(this.questionSet.id).subscribe((data) => {
          this.notify.info("Redirecting to question set list page.");
          this.notify.success("question set deleted.");
          this.notify.blockUi(false);
          setTimeout(() => {
            this.router.viewQuestionSets();     
          }, 300);
        },
        (error) => {
          if (HttpHelper.isValidationError(error)) {
            const msgs = FormHelper.fieldValidationErrors(error, 'id')
            const msg = msgs.length ? msgs[0] : "Unable to delete."
            this.notify.warning(msg);
          } else {
            this.notify.error("Unable to delete question set.");
          }
          this.notify.blockUi(false);
        });
      }
    });
  }

  
  showToAddQuestion() {
    const bsModalRef = this.modalService.show(QuestionCreateDialogComponent, this.config);
    bsModalRef.content.setQuestionSet(this.questionSet);
    bsModalRef.content.afterAdd.subscribe((question: Question) => {
      this.addQuestion(question);    
    });
  }
  showToAddChildQuestion(model: Question) {
    const bsModalRef = this.modalService.show(ChildQuestionCreateDialogComponent, this.config);
    bsModalRef.content.setParent(model);
    bsModalRef.content.afterAdd.subscribe((hierarchy: SurveyQuestionHierarchy) => {
      this.deleteQuestion(hierarchy.parent);
      this.addQuestion(hierarchy.parent);
      this.addQuestion(hierarchy.child);
    });
  }
  canDeleteQuestion(model: Question): boolean {
    var hasNoOptions: boolean = this.getAnswerOptions(model.questionId).length == 0;
    var hasNoChildQuestion: boolean = this.getChildQuestions(model).length == 0;
    var result: boolean = hasNoOptions && hasNoChildQuestion;
    return result;
  }
  canDeleteChildQuestion(model: Question): boolean {
    var hasNoOptions: boolean = this.getAnswerOptions(model.questionId).length == 0;
    return hasNoOptions;
  }
  showToUpdateQuestion(model: Question) {
    const bsModalRef = this.modalService.show(QuestionUpdateDialogComponent, this.config);
    bsModalRef.content.setQuestion(model);
    bsModalRef.content.afterUpdate.subscribe((question: Question) => {
      this.deleteQuestion(question);
      this.addQuestion(question);
    });
  }
  showToUpdateChildQuestion(model: Question) {
    const bsModalRef = this.modalService.show(ChildQuestionUpdateDialogComponent, this.config);
    bsModalRef.content.setQuestion(model);
    bsModalRef.content.afterUpdate.subscribe((question: Question) => {
      this.deleteQuestion(question);
      this.addQuestion(question);
    });
  }
  confirmToDeleteQuestion(model: Question) {
    this.notify.ask(`Do you want to delte this question?`)
    .then((confirm) => {
      if (confirm) {
        this.notify.blockUi();
        this.service.removeQuestion(model.questionId).subscribe((data) => {
          this.deleteQuestion(model);
          if(data.parent != null) {
            this.deleteQuestion(data.parent);
            this.addQuestion(data.parent);      
          }
          if(data.child != null) {
            this.deleteQuestion(data.child);
            this.addQuestion(data.child);      
          }

          this.notify.success("question deleted.");
          this.notify.blockUi(false);
        },
        (error) => {
          if (HttpHelper.isValidationError(error)) {
            const msgs = FormHelper.fieldValidationErrors(error, 'id')
            const msg = msgs.length ? msgs[0] : "Unable to delete."
            this.notify.warning(msg);
          } else {
            this.notify.error("Unable to delete question.");
          }
          this.notify.blockUi(false);
        });
      }
    });  
  }


  showToAddAnswerOption(model: Question) {
    const bsModalRef = this.modalService.show(QuestionOptionCreateDialogComponent, this.config);
    bsModalRef.content.setQuestion(model);
    bsModalRef.content.afterAdd.subscribe(option => {
      this.addOption(option);
    });
  }
  showToUpdateAnswerOption(model: QuestionAnswerOption) {
    const bsModalRef = this.modalService.show(QuestionOptionUpdateDialogComponent, this.config);
    bsModalRef.content.setOption(model);
    bsModalRef.content.afterUpdate.subscribe(option => {
      this.deleteOption(model);
      this.addOption(option);
    });
  }
  confirmToDeleteAnswerOption(model: QuestionAnswerOption) {
    this.notify.ask(`Do you want to remove this option?`)
    .then((confirm) => {
      if (confirm) {
        this.notify.blockUi();
        this.service.deleteAnswerOption(model.answerId).subscribe((data) => {
          this.notify.success("Option deleted.");
          this.deleteOption(model);
          this.notify.blockUi(false);
        },
          error => {
            this.notify.error("Unable to delete option.");
            this.notify.blockUi(false);
          });
      }
    });
  }


  ngOnInit() {
    /*https://stackoverflow.com/a/48125257*/
    const param1: string = this.route.snapshot.queryParams.id;  
    const id: number = Number(param1);
    this.notify.blockUi();
    forkJoin([
      this.service.questionSet(id),
      this.service.questions(id),
      this.service.answerOptions(id), 
    ]).subscribe((res) => {
      this.questionSet = res[0];
      this.questions = res[1];
      this.questionAnswerOptions = res[2];
      this.notify.blockUi(false);
    },
    error => {
      this.notify.error("Error to load page.");
      this.notify.blockUi(false);
    });
  }
}
