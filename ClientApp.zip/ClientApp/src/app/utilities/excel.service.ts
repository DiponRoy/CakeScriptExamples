/*
https://medium.com/@madhavmahesh/exporting-an-excel-file-in-angular-927756ac9857
https://stackoverflow.com/questions/39177183/how-to-export-json-to-csv-or-excel-angular-2

read:
https://stackoverflow.com/questions/47151035/angular-4-how-to-read-data-from-excel
https://github.com/SheetJS/js-xlsx
*/

import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()
export class ExcelService {
  constructor() { }
  public exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  public readFile(fileReader: FileReader, sheetNumber = 0): any[] {
    const arrayBuffer: any = fileReader.result;
    var data = new Uint8Array(arrayBuffer);
    var arr = new Array();
    for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
    var bstr = arr.join("");
    var workbook = XLSX.read(bstr, { type: "binary" });
    var first_sheet_name = workbook.SheetNames[sheetNumber];
    var worksheet = workbook.Sheets[first_sheet_name];

    var dataRows = XLSX.utils.sheet_to_json(worksheet, { raw: true });
    return dataRows;
  }

  public readFileAs<T>(fileReader: FileReader, sheetNumber = 0): T[] {
    const arrayBuffer: any = fileReader.result;
    var data = new Uint8Array(arrayBuffer);
    var arr = new Array();
    for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
    var bstr = arr.join("");
    var workbook = XLSX.read(bstr, { type: "binary" });
    var first_sheet_name = workbook.SheetNames[sheetNumber];
    var worksheet = workbook.Sheets[first_sheet_name];

    var dataRows = XLSX.utils.sheet_to_json<T>(worksheet, { raw: true });
    return dataRows;
  }

}