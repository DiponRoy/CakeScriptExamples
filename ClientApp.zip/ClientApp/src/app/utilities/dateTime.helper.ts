import * as moment from 'moment';

export class DateTimeHelper {
    public static dateStringFormat:string = "DD-MMM, YYYY";              /*30-Jan, 2019*/
    public static dateTimeStringFormat:string = "DD-MMM,YYYY hh:mm A";  /*30-Jan, 2019 11:50 PM*/


    public static toFormat(dateTime: Date, format: string): string {
      let value: string = '';
      if(dateTime){
        value = moment(dateTime).format(format);
      }    
      return value;
    }

    public static dateString(dateTime: Date): string {
      let value: string = this.toFormat(dateTime, this.dateStringFormat);  
      return value;
    }

    public static dateTimeString(dateTime: Date): string {
        let value: string = this.toFormat(dateTime, this.dateTimeStringFormat);  
        return value;
    }

    public static date(dateTime: Date): Date {
      var dateObj = moment(dateTime);
      var dateValue = moment({
          year: dateObj.year(),
          month: dateObj.month(),
          day: dateObj.date()
      });
      var value = dateValue.toDate();
      return value;
    }

    public static removeLocalDate(dateTime: Date): Date {
      var m = moment(dateTime);
      var result = moment(m).add(m.utcOffset(), 'm').utc();
      var value = result.toDate();
      return value;
    }
}