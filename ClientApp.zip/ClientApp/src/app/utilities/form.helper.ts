import { FormGroup } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { AutocompleteComponent } from 'angular-ng-autocomplete';

export class FormHelper {

    // public static removeControlErrors(form: FormGroup): void {
    //     Object.keys(form.controls).forEach(key => {
    //         form.controls[key].setErrors(null);
    //         // this.loginForm.controls[key].reset();
    //         // this.loginForm.controls[key].markAsPristine();
    //         // this.loginForm.controls[key].markAsUntouched();
    //         // this.loginForm.controls[key].updateValueAndValidity();
    //       });
    // }


    public static startValidating(form: FormGroup): void {
        Object.keys(form.controls).forEach(key => {
            form.controls[key].markAsDirty();
            form.controls[key].updateValueAndValidity(); /*impt for popups*/
        });
    }

    public static removeControlErrors(form: FormGroup): void {
        Object.keys(form.controls).forEach(key => {
            form.controls[key].setErrors(null);
        });
    }

    public static fieldValidationErrors(httpError: HttpErrorResponse, fileName: string = 'id'): string[] {
        let msgs: string[];
        let errors = httpError.error.errors;
        for (var item in errors) {
            if (item.toLowerCase() === fileName.toLowerCase()) {
                msgs = errors[item];
            }
        }
        return msgs;
    }

    static camelCase(value: string): string {
        let result = value.charAt(0).toLowerCase() + value.slice(1);
        return result;
    }

    public static mappValidationErrorsToList(forms: FormGroup[], errorPropPrefix: string, httpError: HttpErrorResponse): void {
        // forms.forEach(form => {
        //     let control = form.controls.id;       
        //     control.setErrors({serverError123: {message: 'sdfsdf.'}})          
        // });
        debugger;
        errorPropPrefix = this.camelCase(errorPropPrefix);
        errorPropPrefix = errorPropPrefix.replace("[", "");
        errorPropPrefix = errorPropPrefix + "[";

        const indexNamePrefix: string = "ServerError";
        let errors = httpError.error.errors;
        let errorCount = 0;
        /*error.status should be 400*/
        for (var fieldName in errors) {
            const fieldNameCamel = this.camelCase(fieldName);
            if (!fieldNameCamel.startsWith(errorPropPrefix)) {
                continue;
            }

            let index = Number(fieldName.split('[')[1].split(']')[0]);
            let propName = fieldName.split('.')[1]
            const controlName = this.camelCase(propName);
            const control = forms[index].controls[controlName];
            debugger;
            if (control === undefined) {
            } else {
                errors[fieldName].forEach(element => {
                    ++errorCount;
                    const indexName = indexNamePrefix + errorCount;
                    var validation = {};
                    validation[indexName] = {
                        message: element
                    };
                    control.setErrors(validation);
                });
            }
        }
    }

    public static mappValidationErrors(form: FormGroup, httpError: HttpErrorResponse): void {
        //this.form.controls.userName.setErrors({serverError: {message: 'sdfsdf.'}})

        const indexNamePrefix: string = "ServerError";
        let errors = httpError.error.errors;

        /*error.status should be 400*/
        for (var fieldName in errors) {
            const controlName = fieldName.charAt(0).toLowerCase() + fieldName.slice(1);
            const control = form.controls[controlName];
            if (control === undefined) {
            } else {
                let index = 0;
                errors[fieldName].forEach(element => {
                    ++index;
                    const indexName = indexNamePrefix + index;
                    var validation = {};
                    validation[indexName] = {
                        message: element
                    };
                    control.setErrors(validation);
                });
            }
        }
    }

    public static clean(form: FormGroup): void {
        form.reset();
        form.markAsPristine();
        this.removeControlErrors(form);
    }


    public static cleanAutocomplete(auto: AutocompleteComponent): void {
        auto.clear();
        auto.close();
    }
}


export class HttpHelper {
    public static isValidationError(error: HttpErrorResponse): boolean {
        const value = error.status === 400;
        return value;
    }
}
