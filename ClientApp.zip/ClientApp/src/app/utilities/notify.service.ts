/*
toaster: https://www.npmjs.com/package/ngx-toastr
*/

import { Injectable } from '@angular/core';
import { Promise } from 'es6-promise';
import { ToastrService } from 'ngx-toastr';
import { ConfirmDialogService } from '../elements/confirm-dialog/confirm-dialog.service';
import { NgxSpinnerService } from 'ngx-spinner';


@Injectable()
export class NotifyService {
  constructor(private spinner: NgxSpinnerService, private toastrService: ToastrService, private confirmService: ConfirmDialogService) { }

  public info(message: string, title: string = "Info!"): void {
    this.toastrService.info(message, title);
  }
  public success(message: string, title: string = "Success!"): void {
    this.toastrService.success(message, title);
  }
  public warning(message: string, title: string = "Warning!"): void {
    this.toastrService.warning(message, title);
  }
  public error(message: string, title: string = "Error!"): void {
    this.toastrService.error(message, title);
  }


  public ask(
    message: string,
    title: string = "Confirm",
    btnOkText: string = 'Yes',
    btnCancelText: string = 'Cancel'): Promise<boolean> {
    return this.confirmService.confirm(
      message,
      title,
      btnOkText,
      btnCancelText)
  }


  public blockUi(flag: boolean = true) {
    if (flag) {
      this.spinner.show();
    } else {
      this.spinner.hide();
    }
  }
}